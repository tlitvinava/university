const mongoose = require('mongoose');

const EmployeeSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true,
        maxlength: 100,
        trim: true,
    },
    position: {
        type: String,
        required: true,
        maxlength: 100,
        trim: true,
    },
    photo: {
        type: String, // Path to the photo
    },
    phone: {
        type: String,
        maxlength: 20,
        default: '',
    },
    email: {
        type: String,
        trim: true,
        lowercase: true,
        default: '',
    },
    description: {
        type: String,
        required: true,
    },
}, {
    timestamps: true,
});

module.exports = mongoose.model('Employee', EmployeeSchema);
