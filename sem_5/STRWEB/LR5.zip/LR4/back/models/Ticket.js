const mongoose = require('mongoose');

const STATUS_CHOICES = ['pending', 'confirmed', 'cancelled'];

const TicketSchema = new mongoose.Schema({
    date_of_purchase: {
        type: Date,
        required: true,
    },
    number_of_attendees: {
        type: Number,
        required: true,
        min: 1,
    },
    contact_phone_number: {
        type: String,
        required: true,
        maxlength: 20,
    },
    date_of_attendance: {
        type: Date,
        required: true,
    },
    status: {
        type: String,
        enum: STATUS_CHOICES,
        default: 'pending',
    },
    overall_cost: {
        type: mongoose.Schema.Types.Decimal128,
        required: true,
    },
    user: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true,
    },
    additional_services: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'AdditionalService',
    }],
    promo_code: {
        type: mongoose.Schema.Types.ObjectId,
        // ref: 'PromoCode',
        default: null,
    },
}, {
    timestamps: true,
});

module.exports = mongoose.model('Ticket', TicketSchema);
