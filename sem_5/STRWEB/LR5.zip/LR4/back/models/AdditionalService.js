const mongoose = require('mongoose');

const AdditionalServiceSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true,
        maxlength: 100,
        trim: true,
    },
    description: {
        type: String,
        required: true,
    },
    cost: {
        type: mongoose.Schema.Types.Decimal128,
        required: true,
    },
    available: {
        type: Boolean,
        default: true,
    },
    duration_minutes: {
        type: Number,
        default: null,
    },
}, {
    timestamps: true, // Adds createdAt and updatedAt fields
});

AdditionalServiceSchema.statics.castFromDatabaseFormat = function(updatedService) {
    return {
        id: updatedService._id,
        name: updatedService.name,
        description: updatedService.description,
        cost: parseFloat(updatedService.cost.toString()),
        available: updatedService.available,
        duration_minutes: updatedService.duration_minutes
    };
};

module.exports = mongoose.model('AdditionalService', AdditionalServiceSchema);
