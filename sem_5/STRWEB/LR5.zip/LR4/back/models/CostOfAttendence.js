const mongoose = require('mongoose');

const DAYS_OF_WEEK = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

const CostOfAttendanceSchema = new mongoose.Schema({
    day_of_week: {
        type: String,
        required: true,
        enum: DAYS_OF_WEEK,
        unique: true,
    },
    cost: {
        type: mongoose.Schema.Types.Decimal128,
        required: true,
    },
}, {
    timestamps: true,
});

module.exports = mongoose.model('CostOfAttendance', CostOfAttendanceSchema);
