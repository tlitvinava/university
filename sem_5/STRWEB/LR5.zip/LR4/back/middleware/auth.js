const jwt = require('jsonwebtoken');
// const passport = require('../passport');

const protect = (req, res, next) => {
    const token = req.headers['authorization'] && req.headers['authorization'].split(' ')[1];
    if (!token) return res.status(401).json({ message: 'Необходимо авторизоваться' });

    try {
        const decoded = jwt.verify(token, 'секретный_ключ');
        req.user = decoded;
        next();
    } catch (error) {
        res.status(401).json({ message: 'Неавторизованный доступ' });
    }
};

module.exports = protect;
