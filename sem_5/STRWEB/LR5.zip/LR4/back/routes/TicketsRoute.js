const express = require('express');
const mongoose = require('mongoose');
const Ticket = require('../models/Ticket');  // Путь к вашей модели
const router = express.Router();

// Роут для получения всех билетов (GET /api/tickets)
router.get('/', async (req, res) => {
    try {
        const tickets = await Ticket.find()
            .populate('user', 'email')  // Заполняем данные пользователя, чтобы получать email
            .populate('additional_services', 'name cost')  // Заполняем дополнительные услуги
            .populate('promo_code', 'code discount');  // Заполняем промокоды, если это нужно

        res.status(200).json(tickets);  // Отправляем список билетов в ответе
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Ошибка при получении билетов' });
    }
});

// Роут для создания массива билетов (POST /api/tickets)
router.post('/', async (req, res) => {
    try {
        const ticketsData = req.body;  // Данные билетов, отправленные в запросе

        // Проверка, что пришел массив билетов
        if (!Array.isArray(ticketsData)) {
            return res.status(400).json({ message: 'Ожидается массив билетов' });
        }

        // Создание и сохранение массива билетов
        const tickets = await Ticket.insertMany(ticketsData);

        res.status(201).json(tickets);  // Отправляем успешно созданные билеты
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Ошибка при создании билетов' + error.message });
    }
});

module.exports = router;
