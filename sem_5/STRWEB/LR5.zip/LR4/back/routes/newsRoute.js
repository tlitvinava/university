const express = require('express');
const mongoose = require('mongoose');
const router = express.Router();

// Import the News model
const News = require('../models/News');

// Get all news articles (GET /api/news)
router.get('/', async (req, res) => {
    try {
        const news = await News.find();
        res.status(200).json(news);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// Create new news articles (POST /api/news)
router.post('/', async (req, res) => {
    try {
        // Ensure the request body is an array of news objects
        if (!Array.isArray(req.body)) {
            return res.status(400).json({ message: 'Request body must be an array of news objects' });
        }

        const newsItems = req.body.map(item => {
            // For each item in the array, create a new News document
            return new News({
                title: item.title,
                summary: item.summary,
                content: item.content,
                image: item.image, // Optional field
            });
        });

        // Save all the new News articles at once
        const savedNewsItems = await News.insertMany(newsItems);

        res.status(201).json(savedNewsItems); // Return the created news articles
    } catch (error) {
        res.status(400).json({ message: error.message });
    }
});

module.exports = router;
