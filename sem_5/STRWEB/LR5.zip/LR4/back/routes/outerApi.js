const express = require('express');
const router = express.Router();
const axios = require('axios')

// Route to fetch cat breeds
router.get('/cat_breeds', async (req, res) => {
    const url = 'https://api.thecatapi.com/v1/breeds';

    try {
        const response = await axios.get(url);
        res.json(response.data); // Send the JSON data from the API
    } catch (error) {
        console.error('Error fetching cat breeds:', error);
        res.status(500).json({ error: 'Failed to fetch cat breeds' });
    }
});

// Route to fetch dog
router.get('/dog_breeds', async (req, res) => {
    const url = 'https://api.thedogapi.com/v1/breeds';

    try {
        const response = await axios.get(url);
        res.json(response.data); // Send the JSON data from the API
    } catch (error) {
        console.error('Error fetching dog breeds:', error);
        res.status(500).json({ error: 'Failed to fetch dog breeds' });
    }
});

module.exports = router;