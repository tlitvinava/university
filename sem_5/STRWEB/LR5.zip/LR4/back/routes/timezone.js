const express = require('express');
const router = express.Router();
const axios = require('axios')
const moment = require("moment-timezone");
const AdditionalService = require("../models/AdditionalService");
const {json} = require("express");

router.get("/time-info",  async (req, res) => {
    try {
        // const timezone = req.query.timezone; // Get user's timezone from query
        //
        // if (!timezone || !moment.tz.zone(timezone)) {
        //     return res.status(400).json({ error: "Invalid or missing timezone" });
        // }

        let offsetInMinutes;
        offsetInMinutes = req.query['offsetInMinutes'];

        const offsetHours = -offsetInMinutes / 60;

        // Ищем соответствующую таймзону
        const timezones = moment.tz.names();
        const matchingZones = timezones.filter(zone => {
            const a = moment.tz(zone).utcOffset()
            return moment.tz(zone).utcOffset() == -offsetInMinutes;
        });

        const timezone = matchingZones[0];

        // Find the most recently updated record
        const latestRecord = await AdditionalService.findOne().sort({ updatedAt: -1 }).limit(1);

        const userTime = moment().tz(timezone).format("YYYY-MM-DD HH:mm:ss");
        const utcTime = moment().utc().format("YYYY-MM-DD HH:mm:ss");
        const lastUpdatedLocal = latestRecord
            ? moment(latestRecord.updatedAt).tz(timezone).format("YYYY-MM-DD HH:mm:ss")
            : null;
        const lastUpdatedUTC = latestRecord
            ? moment(latestRecord.updatedAt).utc().format("YYYY-MM-DD HH:mm:ss")
            : null;

        res.json({
            userTime,
            utcTime,
            lastUpdatedLocal,
            lastUpdatedUTC,
        });
    } catch (err) {
        res.status(500).json({ error: 'Error fetching time information ' + err.message });
    }
});

module.exports = router;