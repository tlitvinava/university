const express = require('express');
const mongoose = require('mongoose');
const router = express.Router();
const protect = require('../middleware/auth');

// Import the AdditionalService model
const AdditionalService = require('../models/AdditionalService');

// Create a new AdditionalService (POST /api/additional-services)
router.post('/', protect, async (req, res) => {
    try {
        const additionalService = new AdditionalService(req.body);
        const savedService = await additionalService.save();

        const result = AdditionalService.castFromDatabaseFormat(savedService);
        res.status(201).json(result);
    } catch (error) {
        res.status(400).json({ message: error.message });
    }
});

// Get all AdditionalServices (GET /api/additional-services)
// router.get('/', async (req, res) => {
//     try {
//         const services = await AdditionalService.find();
//         let servicesRes = []
//         for (const service of services) {
//             servicesRes.push(AdditionalService.castFromDatabaseFormat(service));
//         }
//         res.status(200).json(servicesRes);
//     } catch (error) {
//         res.status(500).json({ message: error.message });
//     }
// });

router.get('/', async (req, res) => {
    try {
        const { search, sortBy = 'createdAt', sortOrder = 'desc' } = req.query;

        // Build the search query
        const searchQuery = {};
        if (search) {
            searchQuery.$or = [
                { name: { $regex: search, $options: 'i' } }, // Case-insensitive search on name
                { description: { $regex: search, $options: 'i' } }, // Case-insensitive search on description
            ];
        }

        // Define the sorting order
        const sortOrderValue = sortOrder === 'asc' ? 1 : -1;
        const sortObject = { [sortBy]: sortOrderValue };

        // Fetch data with search and sorting applied
        const services = await AdditionalService.find(searchQuery).sort(sortObject);

        // Format the response
        let servicesRes = [];
        for (const service of services) {
            servicesRes.push(AdditionalService.castFromDatabaseFormat(service));
        }

        res.status(200).json(servicesRes);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// Get a single AdditionalService by ID (GET /api/additional-services/:id)
router.get('/:id', async (req, res) => {
    try {
        const service = await AdditionalService.findById(req.params.id);
        if (!service) return res.status(404).json({ message: 'Service not found' });
        res.status(200).json(AdditionalService.castFromDatabaseFormat(service));
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// Update an AdditionalService by ID (PUT /api/additional-services/:id)
router.put('/:id', protect, async (req, res) => {
    try {
        const updatedService = await AdditionalService.findByIdAndUpdate(
            req.params.id,
            req.body,
            { new: true, runValidators: true } // Return the updated document
        );
        if (!updatedService) return res.status(404).json({ message: 'Service not found' });
        res.status(200).json(AdditionalService.castFromDatabaseFormat(updatedService));
    } catch (error) {
        res.status(400).json({ message: error.message });
    }
});

// Delete an AdditionalService by ID (DELETE /api/additional-services/:id)
router.delete('/:id', protect, async (req, res) => {
    try {
        const deletedService = await AdditionalService.findByIdAndDelete(req.params.id);
        if (!deletedService) return res.status(404).json({ message: 'Service not found' });
        res.status(200).json({ message: 'Service deleted successfully' });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

module.exports = router;
