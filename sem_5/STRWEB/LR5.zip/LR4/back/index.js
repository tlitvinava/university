// app.js
const express = require('express');
const mongoose = require('mongoose');
const passport = require('passport');
const session = require('express-session');

const app = express();
const port = 3001;
const cors = require('cors');

const corsOptions = {
    origin: 'http://localhost:3000',  // Replace with your frontend URL
    methods: 'GET,HEAD,PUT,PATCH,POST,DELETE',
    credentials: true,  // Allows credentials like cookies or authentication headers
};

app.use(cors(corsOptions));

app.use(express.json());

// app.use(session({ secret: process.env.CLIENT_SECRET, resave: false, saveUninitialized: true }));
// app.use(passport.initialize());
// app.use(passport.session());

const protect = require('./middleware/auth');

const mongoURI = process.env.MONGO_URI || 'mongodb://admin:adminpassword@localhost:27017/web_db?authSource=admin';
mongoose
    .connect(mongoURI, { useNewUrlParser: true, useUnifiedTopology: true })
    .then(() => console.log('MongoDB подключена'))
    .catch((error) => console.error('Ошибка подключения к MongoDB:', error));


const additionalServiceRoutes = require('./routes/additionalServiceRoutes');
app.use('/api/additional-services', additionalServiceRoutes);

const authRoutes = require('./routes/auth');
app.use('/api/auth', authRoutes);

const newsRoutes = require('./routes/newsRoute');
app.use('/api/news', newsRoutes);

const ticketRoutes = require('./routes/TicketsRoute');  // Путь к вашему маршруту
app.use('/api/tickets', ticketRoutes);  // Используем маршруты для работы с билетами


const outerApiRoutes = require('./routes/outerApi');
app.use('/api', outerApiRoutes);

const timeInfo = require('./routes/timezone');
app.use('/api', timeInfo);

// const authRoutesGoogle = require('./routes/authGoogle');
// app.use('/auth', authRoutesGoogle);


app.get('/', (req, res) => {
    res.send('Hello, Express!');
});

app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});
