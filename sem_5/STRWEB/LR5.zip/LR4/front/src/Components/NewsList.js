import React, { useState, useEffect } from 'react';
import axios from '../axios'; // Путь к вашему axios экземпляру
import './Styles/NewsList.css'; // Импортируем файл CSS

const NewsList = () => {
    const [news, setNews] = useState([]);

    useEffect(() => {
        // Загружаем новости при монтировании компонента
        axios.get('/api/news') // Предположим, что этот рут возвращает список новостей
            .then((response) => setNews(response.data))
            .catch((error) => console.error('Ошибка загрузки новостей:', error));
    }, []);

    return (
        <div className="news-list-container">
            <h2 className="news-list-title">Новости зоопарка</h2>
            <ul className="news-list">
                {news.map((newsItem) => (
                    <li key={newsItem.id} className="news-item">
                        <h3 className="news-item-title">{newsItem.title}</h3>
                        <p className="news-item-summary"><strong>Сводка:</strong> {newsItem.summary}</p>
                        <p className="news-item-content">{newsItem.content}</p>
                        {newsItem.image && <img className="news-item-image" src={newsItem.image} alt={newsItem.title} />}
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default NewsList;
