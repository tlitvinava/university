from setuptools import setup, find_packages

setup(
    name='TSerializerPack',
    version='0.1.0',
    packages=find_packages(),
    description='Universal serializer for my_project classes',
    author='Taisia',
    author_email='t.litvinava@gmail.com',
    python_requires='>=3.7',
)
