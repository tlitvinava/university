import json
import xml.etree.ElementTree as ET

class UniversalSerializer:
    def __init__(self, cls):
        self.cls = cls

    def _to_dict(self, obj):
        if isinstance(obj, list):
            return [self._to_dict(item) for item in obj]
        elif hasattr(obj, '__dict__'):
            result = {}
            for key, value in obj.__dict__.items():
                result[key] = self._to_dict(value)
            return result
        else:
            return obj

    def _from_dict(self, d):
        if isinstance(d, dict):
            obj = self.cls.__new__(self.cls)
            non_recursive = getattr(self.cls, "__non_recursive_fields__", [])

            for key, value in d.items():
                if key in non_recursive:
                    setattr(obj, key, value)
                else:
                    setattr(obj, key, self._from_dict(value))
            return obj
        elif isinstance(d, list):
            return [self._from_dict(item) for item in d]
        else:
            return d

    def serialize_json(self, obj):
        return json.dumps(self._to_dict(obj), ensure_ascii=False, indent=4)

    def deserialize_json(self, data):
        return self._from_dict(json.loads(data))

    def dump_json(self, obj, filepath):
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(self.serialize_json(obj))

    def load_json(self, filepath):
        with open(filepath, 'r', encoding='utf-8') as f:
            return self.deserialize_json(f.read())

    def serialize_xml(self, obj):
        root = ET.Element("object")
        self._dict_to_xml(self._to_dict(obj), root)
        return ET.tostring(root, encoding="unicode")

    def deserialize_xml(self, data):
        root = ET.fromstring(data)
        d = self._xml_to_dict(root)
        return self._from_dict(d)

    def dump_xml(self, obj, filepath):
        xml = self.serialize_xml(obj)
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(xml)

    def load_xml(self, filepath):
        with open(filepath, 'r', encoding='utf-8') as f:
            return self.deserialize_xml(f.read())

    def _dict_to_xml(self, data, root):
        for key, value in data.items():
            el = ET.SubElement(root, key)
            if isinstance(value, dict):
                self._dict_to_xml(value, el)
            elif isinstance(value, list):
                for item in value:
                    item_el = ET.SubElement(el, "item")
                    if isinstance(item, dict):
                        self._dict_to_xml(item, item_el)
                    else:
                        item_el.text = str(item)
            else:
                el.text = str(value)

    def _xml_to_dict(self, element):
        result = {}
        for child in element:
            if len(child) > 0 and all(grand.tag == "item" for grand in child):
                result[child.tag] = []
                for item in child:
                    result[child.tag].append(self._xml_to_dict(item) if len(item) > 0 else item.text)
            elif len(child) > 0:
                result[child.tag] = self._xml_to_dict(child)
            else:
                result[child.tag] = child.text
        return result
