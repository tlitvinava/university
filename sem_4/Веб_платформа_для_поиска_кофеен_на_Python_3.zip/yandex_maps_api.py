"""
Интеграция с API Яндекс.Карт для получения данных о кофейнях.
"""
import os
import json
import time
import requests
from typing import Dict, List, Any, Optional, Tuple

from src.business.models.cafe import Cafe


class YandexMapsAPI:
    """
    Класс для работы с API Яндекс.Карт.
    """
    def __init__(self, api_key: str = None):
        """
        Инициализация API.
        
        Args:
            api_key: API-ключ Яндекс.Карт
        """
        # В реальном проекте API-ключ должен храниться в конфигурации
        # или переменных окружения, а не в коде
        self.api_key = api_key or os.environ.get('YANDEX_MAPS_API_KEY', '')
        self.base_url = "https://search-maps.yandex.ru/v1/"
        
    def search_cafes(self, query: str = "кофейня", location: str = "Минск", 
                     radius: int = 5000, limit: int = 50) -> Tuple[bool, str, List[Dict[str, Any]]]:
        """
        Поиск кофеен по заданным параметрам.
        
        Args:
            query: Поисковый запрос
            location: Местоположение (город или координаты)
            radius: Радиус поиска в метрах
            limit: Максимальное количество результатов
            
        Returns:
            Кортеж (успех, сообщение, список кофеен)
        """
        # Проверка наличия API-ключа
        if not self.api_key:
            return False, "API-ключ Яндекс.Карт не указан", []
        
        # Параметры запроса
        params = {
            "apikey": self.api_key,
            "text": query,
            "lang": "ru_RU",
            "type": "biz",
            "results": limit
        }
        
        # Добавляем координаты или город
        if "," in location:
            # Если переданы координаты (формат: "широта,долгота")
            params["ll"] = location
            params["spn"] = f"{radius/111000},{radius/111000}"  # Примерный перевод метров в градусы
        else:
            # Если передан город
            params["text"] = f"{query} {location}"
        
        try:
            # Выполняем запрос к API
            response = requests.get(self.base_url, params=params)
            
            # Проверяем статус ответа
            if response.status_code != 200:
                return False, f"Ошибка API: {response.status_code}", []
            
            # Парсим JSON-ответ
            data = response.json()
            
            # Проверяем наличие результатов
            if "features" not in data or not data["features"]:
                return False, "Кофейни не найдены", []
            
            return True, "Кофейни успешно найдены", data["features"]
        
        except Exception as e:
            return False, f"Ошибка при выполнении запроса: {str(e)}", []
    
    def get_cafe_details(self, cafe_id: str) -> Tuple[bool, str, Optional[Dict[str, Any]]]:
        """
        Получение детальной информации о кофейне по ID.
        
        Args:
            cafe_id: ID кофейни в Яндекс.Картах
            
        Returns:
            Кортеж (успех, сообщение, данные кофейни)
        """
        # Проверка наличия API-ключа
        if not self.api_key:
            return False, "API-ключ Яндекс.Карт не указан", None
        
        # В реальном проекте здесь был бы запрос к API для получения детальной информации
        # Однако, API Яндекс.Карт не предоставляет прямой метод для получения деталей по ID
        # Поэтому мы бы использовали другие методы или сохраняли детали при первом поиске
        
        # Заглушка для демонстрации
        return False, "Метод не реализован в API Яндекс.Карт", None
    
    def convert_to_cafe_model(self, yandex_cafe: Dict[str, Any]) -> Cafe:
        """
        Преобразование данных из API Яндекс.Карт в модель Cafe.
        
        Args:
            yandex_cafe: Данные кофейни из API Яндекс.Карт
            
        Returns:
            Объект модели Cafe
        """
        # Извлекаем необходимые данные
        properties = yandex_cafe.get("properties", {})
        geometry = yandex_cafe.get("geometry", {})
        
        name = properties.get("name", "")
        address = properties.get("description", "")
        
        # Координаты в формате [долгота, широта]
        coordinates = geometry.get("coordinates", [0, 0])
        
        # Преобразуем координаты в нужный формат
        latitude = coordinates[1] if len(coordinates) > 1 else 0
        longitude = coordinates[0] if len(coordinates) > 0 else 0
        
        # Создаем объект кофейни
        cafe = Cafe(
            name=name,
            address=address,
            coordinates={"latitude": latitude, "longitude": longitude},
            external_id=properties.get("CompanyMetaData", {}).get("id", ""),
            description="",  # API не предоставляет описание
            features={}  # Заполняем особенности по мере необходимости
        )
        
        # Добавляем дополнительные данные, если они есть
        company_meta = properties.get("CompanyMetaData", {})
        
        # Часы работы
        if "Hours" in company_meta:
            cafe.features["working_hours"] = company_meta["Hours"].get("text", "")
        
        # Телефоны
        if "Phones" in company_meta:
            phones = [phone.get("formatted", "") for phone in company_meta.get("Phones", [])]
            cafe.features["phones"] = phones
        
        # Категории
        if "Categories" in company_meta:
            categories = [category.get("name", "") for category in company_meta.get("Categories", [])]
            cafe.features["categories"] = categories
        
        return cafe


# Заглушка для демонстрации, так как у нас нет реального API-ключа
class MockYandexMapsAPI(YandexMapsAPI):
    """
    Мок-класс для имитации работы с API Яндекс.Карт.
    """
    def __init__(self):
        """
        Инициализация мок-API.
        """
        super().__init__("mock_api_key")
    
    def search_cafes(self, query: str = "кофейня", location: str = "Минск", 
                     radius: int = 5000, limit: int = 50) -> Tuple[bool, str, List[Dict[str, Any]]]:
        """
        Имитация поиска кофеен.
        
        Args:
            query: Поисковый запрос
            location: Местоположение (город или координаты)
            radius: Радиус поиска в метрах
            limit: Максимальное количество результатов
            
        Returns:
            Кортеж (успех, сообщение, список кофеен)
        """
        # Генерируем тестовые данные
        cafes = []
        
        for i in range(min(10, limit)):
            cafe = {
                "type": "Feature",
                "geometry": {
                    "type": "Point",
                    "coordinates": [27.5 + i * 0.01, 53.9 + i * 0.01]  # Примерные координаты Минска
                },
                "properties": {
                    "name": f"Кофейня {i+1}",
                    "description": f"ул. Примерная, {i+1}",
                    "CompanyMetaData": {
                        "id": f"cafe_{i+1}",
                        "Hours": {
                            "text": "ежедневно, 9:00–22:00"
                        },
                        "Phones": [
                            {
                                "formatted": f"+375 29 123-45-{i+10}"
                            }
                        ],
                        "Categories": [
                            {
                                "name": "Кофейня"
                            },
                            {
                                "name": "Кафе"
                            }
                        ]
                    }
                }
            }
            cafes.append(cafe)
        
        return True, "Кофейни успешно найдены", cafes
