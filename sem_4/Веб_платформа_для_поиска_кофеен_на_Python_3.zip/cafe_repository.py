"""
Репозиторий для работы с кофейнями.
"""
from typing import Dict, List, Any, Optional
import os
import json

from src.business.models.cafe import Cafe, Category, Visit
from src.common.utils.file_utils import (
    read_json_file, write_json_file, append_to_json_list,
    update_json_item, delete_json_item, get_json_item, get_all_json_items
)


class CafeRepository:
    """
    Репозиторий для работы с кофейнями.
    """
    def __init__(self, data_dir: str = None):
        """
        Инициализация репозитория.
        
        Args:
            data_dir: Директория для хранения данных
        """
        if data_dir is None:
            # Используем директорию по умолчанию
            base_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
            data_dir = os.path.join(base_dir, 'data', 'local')
        
        self.data_dir = data_dir
        self.cafes_file = os.path.join(data_dir, 'cafes.json')
        self.categories_file = os.path.join(data_dir, 'categories.json')
        self.visits_file = os.path.join(data_dir, 'visits.json')
        
        # Создаем директорию, если она не существует
        os.makedirs(data_dir, exist_ok=True)
        
        # Инициализируем файлы, если они не существуют
        if not os.path.exists(self.cafes_file):
            write_json_file(self.cafes_file, {'items': []})
        
        if not os.path.exists(self.categories_file):
            write_json_file(self.categories_file, {'items': []})
        
        if not os.path.exists(self.visits_file):
            write_json_file(self.visits_file, {'items': []})
    
    # Методы для работы с кофейнями
    
    def create_cafe(self, cafe: Cafe) -> Optional[Cafe]:
        """
        Создание новой кофейни.
        
        Args:
            cafe: Объект кофейни
            
        Returns:
            Созданная кофейня или None в случае ошибки
        """
        # Проверяем, не существует ли уже кофейня с таким external_id
        if cafe.external_id:
            existing_cafes = self.get_all_cafes()
            
            for existing_cafe in existing_cafes:
                if existing_cafe.external_id == cafe.external_id:
                    print(f"Cafe with external_id {cafe.external_id} already exists")
                    return None
        
        # Добавляем кофейню
        cafe_dict = cafe.to_dict()
        result = append_to_json_list(self.cafes_file, cafe_dict)
        
        if result:
            return Cafe.from_dict(result)
        
        return None
    
    def update_cafe(self, cafe: Cafe) -> Optional[Cafe]:
        """
        Обновление кофейни.
        
        Args:
            cafe: Объект кофейни
            
        Returns:
            Обновленная кофейня или None в случае ошибки
        """
        if cafe.id is None:
            return None
        
        cafe_dict = cafe.to_dict()
        result = update_json_item(self.cafes_file, cafe.id, cafe_dict)
        
        if result:
            return Cafe.from_dict(result)
        
        return None
    
    def delete_cafe(self, cafe_id: int) -> bool:
        """
        Удаление кофейни.
        
        Args:
            cafe_id: ID кофейни
            
        Returns:
            True, если кофейня успешно удалена, иначе False
        """
        return delete_json_item(self.cafes_file, cafe_id)
    
    def get_cafe_by_id(self, cafe_id: int) -> Optional[Cafe]:
        """
        Получение кофейни по ID.
        
        Args:
            cafe_id: ID кофейни
            
        Returns:
            Объект кофейни или None, если кофейня не найдена
        """
        cafe_dict = get_json_item(self.cafes_file, cafe_id)
        
        if cafe_dict:
            return Cafe.from_dict(cafe_dict)
        
        return None
    
    def get_cafe_by_external_id(self, external_id: str) -> Optional[Cafe]:
        """
        Получение кофейни по внешнему ID.
        
        Args:
            external_id: Внешний ID кофейни
            
        Returns:
            Объект кофейни или None, если кофейня не найдена
        """
        cafes = get_all_json_items(self.cafes_file)
        
        for cafe_dict in cafes:
            if cafe_dict.get('external_id') == external_id:
                return Cafe.from_dict(cafe_dict)
        
        return None
    
    def get_all_cafes(self) -> List[Cafe]:
        """
        Получение всех кофеен.
        
        Returns:
            Список кофеен
        """
        cafes = get_all_json_items(self.cafes_file)
        return [Cafe.from_dict(cafe_dict) for cafe_dict in cafes]
    
    def get_cafes_by_user(self, user_id: int) -> List[Cafe]:
        """
        Получение кофеен, добавленных пользователем.
        
        Args:
            user_id: ID пользователя
            
        Returns:
            Список кофеен
        """
        cafes = get_all_json_items(self.cafes_file)
        return [Cafe.from_dict(cafe_dict) for cafe_dict in cafes if cafe_dict.get('added_by') == user_id]
    
    def get_cafes_by_category(self, category_id: int) -> List[Cafe]:
        """
        Получение кофеен по категории.
        
        Args:
            category_id: ID категории
            
        Returns:
            Список кофеен
        """
        cafes = get_all_json_items(self.cafes_file)
        return [Cafe.from_dict(cafe_dict) for cafe_dict in cafes if category_id in cafe_dict.get('categories', [])]
    
    def get_cafes_by_feature(self, feature_name: str, feature_value: Any) -> List[Cafe]:
        """
        Получение кофеен по особенности.
        
        Args:
            feature_name: Название особенности
            feature_value: Значение особенности
            
        Returns:
            Список кофеен
        """
        cafes = get_all_json_items(self.cafes_file)
        return [Cafe.from_dict(cafe_dict) for cafe_dict in cafes 
                if feature_name in cafe_dict.get('features', {}) 
                and cafe_dict['features'][feature_name] == feature_value]
    
    def get_nearby_cafes(self, latitude: float, longitude: float, radius: float = 1.0) -> List[Cafe]:
        """
        Получение ближайших кофеен.
        
        Args:
            latitude: Широта
            longitude: Долгота
            radius: Радиус поиска в километрах
            
        Returns:
            Список кофеен
        """
        cafes = self.get_all_cafes()
        nearby_cafes = []
        
        for cafe in cafes:
            # Простая проверка расстояния (приближение)
            cafe_lat = cafe.coordinates.get('latitude', 0)
            cafe_lon = cafe.coordinates.get('longitude', 0)
            
            # Приближенное расстояние в километрах
            # В реальном проекте следует использовать более точную формулу
            distance = ((cafe_lat - latitude) ** 2 + (cafe_lon - longitude) ** 2) ** 0.5 * 111
            
            if distance <= radius:
                nearby_cafes.append(cafe)
        
        return nearby_cafes
    
    def increment_visit_count(self, cafe_id: int) -> bool:
        """
        Увеличение счетчика посещений кофейни.
        
        Args:
            cafe_id: ID кофейни
            
        Returns:
            True, если счетчик успешно увеличен, иначе False
        """
        cafe = self.get_cafe_by_id(cafe_id)
        
        if not cafe:
            return False
        
        cafe.increment_visit_count()
        return self.update_cafe(cafe) is not None
    
    # Методы для работы с категориями
    
    def create_category(self, category: Category) -> Optional[Category]:
        """
        Создание новой категории.
        
        Args:
            category: Объект категории
            
        Returns:
            Созданная категория или None в случае ошибки
        """
        # Проверяем, не существует ли уже категория с таким именем
        existing_categories = self.get_all_categories()
        
        for existing_category in existing_categories:
            if existing_category.name.lower() == category.name.lower():
                print(f"Category with name {category.name} already exists")
                return None
        
        # Добавляем категорию
        category_dict = category.to_dict()
        result = append_to_json_list(self.categories_file, category_dict)
        
        if result:
            return Category.from_dict(result)
        
        return None
    
    def update_category(self, category: Category) -> Optional[Category]:
        """
        Обновление категории.
        
        Args:
            category: Объект категории
            
        Returns:
            Обновленная категория или None в случае ошибки
        """
        if category.id is None:
            return None
        
        category_dict = category.to_dict()
        result = update_json_item(self.categories_file, category.id, category_dict)
        
        if result:
            return Category.from_dict(result)
        
        return None
    
    def delete_category(self, category_id: int) -> bool:
        """
        Удаление категории.
        
        Args:
            category_id: ID категории
            
        Returns:
            True, если категория успешно удалена, иначе False
        """
        return delete_json_item(self.categories_file, category_id)
    
    def get_category_by_id(self, category_id: int) -> Optional[Category]:
        """
        Получение категории по ID.
        
        Args:
            category_id: ID категории
            
        Returns:
            Объект категории или None, если категория не найдена
        """
        category_dict = get_json_item(self.categories_file, category_id)
        
        if category_dict:
            return Category.from_dict(category_dict)
        
        return None
    
    def get_category_by_name(self, name: str) -> Optional[Category]:
        """
        Получение категории по имени.
        
        Args:
            name: Имя категории
            
        Returns:
            Объект категории или None, если категория не найдена
        """
        categories = get_all_json_items(self.categories_file)
        
        for category_dict in categories:
            if category_dict.get('name', '').lower() == name.lower():
                return Category.from_dict(category_dict)
        
        return None
    
    def get_all_categories(self) -> List[Category]:
        """
        Получение всех категорий.
        
        Returns:
            Список категорий
        """
        categories = get_all_json_items(self.categories_file)
        return [Category.from_dict(category_dict) for category_dict in categories]
    
    def get_categories_by_user(self, user_id: int) -> List[Category]:
        """
        Получение категорий, созданных пользователем.
        
        Args:
            user_id: ID пользователя
            
        Returns:
            Список категорий
        """
        categories = get_all_json_items(self.categories_file)
        return [Category.from_dict(category_dict) for category_dict in categories 
                if category_dict.get('created_by') == user_id]
    
    # Методы для работы с посещениями
    
    def create_visit(self, visit: Visit) -> Optional[Visit]:
        """
        Создание нового посещения.
        
        Args:
            visit: Объект посещения
            
        Returns:
            Созданное посещение или None в случае ошибки
        """
        visit_dict = visit.to_dict()
        result = append_to_json_list(self.visits_file, visit_dict)
        
        if result:
            # Увеличиваем счетчик посещений кофейни
            self.increment_visit_count(visit.cafe_id)
            return Visit.from_dict(result)
        
        return None
    
    def update_visit(self, visit: Visit) -> Optional[Visit]:
        """
        Обновление посещения.
        
        Args:
            visit: Объект посещения
            
        Returns:
            Обновленное посещение или None в случае ошибки
        """
        if visit.id is None:
            return None
        
        visit_dict = visit.to_dict()
        result = update_json_item(self.visits_file, visit.id, visit_dict)
        
        if result:
            return Visit.from_dict(result)
        
        return None
    
    def delete_visit(self, visit_id: int) -> bool:
        """
        Удаление посещения.
        
        Args:
            visit_id: ID посещения
            
        Returns:
            True, если посещение успешно удалено, иначе False
        """
        return delete_json_item(self.visits_file, visit_id)
    
    def get_visit_by_id(self, visit_id: int) -> Optional[Visit]:
        """
        Получение посещения по ID.
        
        Args:
            visit_id: ID посещения
            
        Returns:
            Объект посещения или None, если посещение не найдено
        """
        visit_dict = get_json_item(self.visits_file, visit_id)
        
        if visit_dict:
            return Visit.from_dict(visit_dict)
        
        return None
    
    def get_all_visits(self) -> List[Visit]:
        """
        Получение всех посещений.
        
        Returns:
            Список посещений
        """
        visits = get_all_json_items(self.visits_file)
        return [Visit.from_dict(visit_dict) for visit_dict in visits]
    
    def get_visits_by_user(self, user_id: int) -> List[Visit]:
        """
        Получение посещений пользователя.
        
        Args:
            user_id: ID пользователя
            
        Returns:
            Список посещений
        """
        visits = get_all_json_items(self.visits_file)
        return [Visit.from_dict(visit_dict) for visit_dict in visits 
                if visit_dict.get('user_id') == user_id]
    
    def get_visits_by_cafe(self, cafe_id: int) -> List[Visit]:
        """
        Получение посещений кофейни.
        
        Args:
            cafe_id: ID кофейни
            
        Returns:
            Список посещений
        """
        visits = get_all_json_items(self.visits_file)
        return [Visit.from_dict(visit_dict) for visit_dict in visits 
                if visit_dict.get('cafe_id') == cafe_id]
