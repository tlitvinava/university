"""
Модуль для сбора и визуализации статистики посещений кофеен.
"""
import os
import json
import time
from typing import Dict, List, Any, Optional, Tuple
import matplotlib.pyplot as plt
import matplotlib
matplotlib.use('Agg')  # Использование не-интерактивного бэкенда

from src.business.models.cafe import Cafe, Visit
from src.data.repositories.cafe_repository import CafeRepository
from src.data.repositories.user_repository import UserRepository


class StatisticsService:
    """
    Сервис для сбора и анализа статистики посещений.
    """
    def __init__(self, cafe_repository: CafeRepository = None, user_repository: UserRepository = None):
        """
        Инициализация сервиса статистики.
        
        Args:
            cafe_repository: Репозиторий кофеен
            user_repository: Репозиторий пользователей
        """
        self.cafe_repository = cafe_repository or CafeRepository()
        self.user_repository = user_repository or UserRepository()
        
        # Создаем директорию для хранения графиков
        base_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
        self.stats_dir = os.path.join(base_dir, 'data', 'statistics')
        os.makedirs(self.stats_dir, exist_ok=True)
    
    def get_user_visit_statistics(self, user_id: int) -> Dict[str, Any]:
        """
        Получение статистики посещений пользователя.
        
        Args:
            user_id: ID пользователя
            
        Returns:
            Словарь со статистикой
        """
        # Получаем пользователя
        user = self.user_repository.get_user_by_id(user_id)
        
        if not user:
            return {
                "success": False,
                "message": "Пользователь не найден"
            }
        
        # Получаем все посещения пользователя
        visits = self.cafe_repository.get_visits_by_user(user_id)
        
        # Получаем избранные кофейни пользователя
        favorite_cafe_ids = user.favorite_cafes
        
        # Базовая статистика
        total_visits = len(visits)
        favorite_visits = len([v for v in visits if v.cafe_id in favorite_cafe_ids])
        rated_visits = len([v for v in visits if v.rating is not None])
        
        # Статистика по кофейням
        cafe_visits = {}
        for visit in visits:
            cafe_id = visit.cafe_id
            if cafe_id not in cafe_visits:
                cafe_visits[cafe_id] = {
                    "count": 0,
                    "total_duration": 0,
                    "ratings": []
                }
            
            cafe_visits[cafe_id]["count"] += 1
            cafe_visits[cafe_id]["total_duration"] += visit.duration
            
            if visit.rating is not None:
                cafe_visits[cafe_id]["ratings"].append(visit.rating)
        
        # Формируем детальную статистику по кофейням
        cafes_stats = []
        for cafe_id, stats in cafe_visits.items():
            cafe = self.cafe_repository.get_cafe_by_id(cafe_id)
            
            if cafe:
                avg_rating = sum(stats["ratings"]) / len(stats["ratings"]) if stats["ratings"] else None
                avg_duration = stats["total_duration"] / stats["count"] if stats["count"] > 0 else 0
                
                cafes_stats.append({
                    "cafe_id": cafe_id,
                    "name": cafe.name,
                    "address": cafe.address,
                    "visit_count": stats["count"],
                    "total_duration": stats["total_duration"],
                    "avg_duration": avg_duration,
                    "avg_rating": avg_rating,
                    "is_favorite": cafe_id in favorite_cafe_ids
                })
        
        # Сортируем по количеству посещений (от большего к меньшему)
        cafes_stats.sort(key=lambda x: x["visit_count"], reverse=True)
        
        # Статистика по времени
        # Группируем посещения по дням недели и часам
        days_of_week = {0: "Понедельник", 1: "Вторник", 2: "Среда", 3: "Четверг", 
                        4: "Пятница", 5: "Суббота", 6: "Воскресенье"}
        
        day_stats = {day: 0 for day in range(7)}
        hour_stats = {hour: 0 for hour in range(24)}
        
        for visit in visits:
            # Преобразуем timestamp в день недели и час
            visit_time = time.localtime(visit.timestamp)
            day_of_week = visit_time.tm_wday  # 0-6 (понедельник-воскресенье)
            hour = visit_time.tm_hour  # 0-23
            
            day_stats[day_of_week] += 1
            hour_stats[hour] += 1
        
        # Преобразуем в списки для удобства использования в графиках
        days_data = [{"day": days_of_week[day], "count": count} for day, count in day_stats.items()]
        hours_data = [{"hour": hour, "count": count} for hour, count in hour_stats.items()]
        
        # Формируем итоговый результат
        result = {
            "success": True,
            "user_id": user_id,
            "username": user.username,
            "total_visits": total_visits,
            "favorite_visits": favorite_visits,
            "rated_visits": rated_visits,
            "cafes": cafes_stats,
            "days_of_week": days_data,
            "hours_of_day": hours_data
        }
        
        return result
    
    def generate_visit_charts(self, user_id: int) -> Dict[str, str]:
        """
        Генерация графиков посещений для пользователя.
        
        Args:
            user_id: ID пользователя
            
        Returns:
            Словарь с путями к сгенерированным графикам
        """
        # Получаем статистику
        stats = self.get_user_visit_statistics(user_id)
        
        if not stats.get("success", False):
            return {
                "success": False,
                "message": stats.get("message", "Ошибка при получении статистики")
            }
        
        # Создаем директорию для графиков пользователя
        user_stats_dir = os.path.join(self.stats_dir, f"user_{user_id}")
        os.makedirs(user_stats_dir, exist_ok=True)
        
        chart_paths = {}
        
        # График посещений по кофейням (топ-5)
        if stats["cafes"]:
            plt.figure(figsize=(10, 6))
            
            # Берем топ-5 кофеен по посещениям
            top_cafes = stats["cafes"][:5]
            
            cafe_names = [cafe["name"] for cafe in top_cafes]
            visit_counts = [cafe["visit_count"] for cafe in top_cafes]
            
            # Создаем горизонтальный бар-график
            bars = plt.barh(cafe_names, visit_counts, color='skyblue')
            
            # Добавляем значения на график
            for i, bar in enumerate(bars):
                plt.text(bar.get_width() + 0.3, bar.get_y() + bar.get_height()/2, 
                        str(visit_counts[i]), va='center')
            
            plt.xlabel('Количество посещений')
            plt.title('Топ-5 наиболее посещаемых кофеен')
            plt.tight_layout()
            
            # Сохраняем график
            cafes_chart_path = os.path.join(user_stats_dir, 'top_cafes.png')
            plt.savefig(cafes_chart_path)
            plt.close()
            
            chart_paths["top_cafes"] = cafes_chart_path
        
        # График посещений по дням недели
        plt.figure(figsize=(10, 6))
        
        days = [day["day"] for day in stats["days_of_week"]]
        day_counts = [day["count"] for day in stats["days_of_week"]]
        
        plt.bar(days, day_counts, color='lightgreen')
        plt.xlabel('День недели')
        plt.ylabel('Количество посещений')
        plt.title('Посещения по дням недели')
        plt.xticks(rotation=45)
        plt.tight_layout()
        
        days_chart_path = os.path.join(user_stats_dir, 'days_of_week.png')
        plt.savefig(days_chart_path)
        plt.close()
        
        chart_paths["days_of_week"] = days_chart_path
        
        # График посещений по часам
        plt.figure(figsize=(12, 6))
        
        hours = [hour["hour"] for hour in stats["hours_of_day"]]
        hour_counts = [hour["count"] for hour in stats["hours_of_day"]]
        
        plt.bar(hours, hour_counts, color='salmon')
        plt.xlabel('Час дня')
        plt.ylabel('Количество посещений')
        plt.title('Посещения по часам')
        plt.xticks(range(0, 24, 2))  # Показываем каждые 2 часа
        plt.grid(axis='y', linestyle='--', alpha=0.7)
        plt.tight_layout()
        
        hours_chart_path = os.path.join(user_stats_dir, 'hours_of_day.png')
        plt.savefig(hours_chart_path)
        plt.close()
        
        chart_paths["hours_of_day"] = hours_chart_path
        
        # Если есть оценки, создаем график средних оценок
        rated_cafes = [cafe for cafe in stats["cafes"] if cafe.get("avg_rating") is not None]
        
        if rated_cafes:
            plt.figure(figsize=(10, 6))
            
            # Берем топ-5 оцененных кофеен
            top_rated_cafes = sorted(rated_cafes, key=lambda x: x["avg_rating"], reverse=True)[:5]
            
            cafe_names = [cafe["name"] for cafe in top_rated_cafes]
            ratings = [cafe["avg_rating"] for cafe in top_rated_cafes]
            
            # Создаем горизонтальный бар-график
            bars = plt.barh(cafe_names, ratings, color='gold')
            
            # Добавляем значения на график
            for i, bar in enumerate(bars):
                plt.text(bar.get_width() + 0.1, bar.get_y() + bar.get_height()/2, 
                        f"{ratings[i]:.1f}", va='center')
            
            plt.xlabel('Средняя оценка')
            plt.title('Топ-5 кофеен по оценкам')
            plt.xlim(0, 5.5)  # Оценки от 0 до 5
            plt.tight_layout()
            
            # Сохраняем график
            ratings_chart_path = os.path.join(user_stats_dir, 'top_rated_cafes.png')
            plt.savefig(ratings_chart_path)
            plt.close()
            
            chart_paths["top_rated_cafes"] = ratings_chart_path
        
        return {
            "success": True,
            "charts": chart_paths
        }
    
    def get_global_statistics(self) -> Dict[str, Any]:
        """
        Получение глобальной статистики по всем пользователям и кофейням.
        
        Returns:
            Словарь с глобальной статистикой
        """
        # Получаем все посещения
        all_visits = self.cafe_repository.get_all_visits()
        
        # Получаем все кофейни
        all_cafes = self.cafe_repository.get_all_cafes()
        
        # Получаем всех пользователей
        all_users = self.user_repository.get_all_users()
        
        # Базовая статистика
        total_visits = len(all_visits)
        total_cafes = len(all_cafes)
        total_users = len(all_users)
        
        # Статистика по кофейням
        cafe_visits = {}
        for visit in all_visits:
            cafe_id = visit.cafe_id
            if cafe_id not in cafe_visits:
                cafe_visits[cafe_id] = {
                    "count": 0,
                    "total_duration": 0,
                    "ratings": []
                }
            
            cafe_visits[cafe_id]["count"] += 1
            cafe_visits[cafe_id]["total_duration"] += visit.duration
            
            if visit.rating is not None:
                cafe_visits[cafe_id]["ratings"].append(visit.rating)
        
        # Формируем детальную статистику по кофейням
        cafes_stats = []
        for cafe_id, stats in cafe_visits.items():
            cafe = self.cafe_repository.get_cafe_by_id(cafe_id)
            
            if cafe:
                avg_rating = sum(stats["ratings"]) / len(stats["ratings"]) if stats["ratings"] else None
                avg_duration = stats["total_duration"] / stats["count"] if stats["count"] > 0 else 0
                
                cafes_stats.append({
                    "cafe_id": cafe_id,
                    "name": cafe.name,
                    "address": cafe.address,
                    "visit_count": stats["count"],
                    "total_duration": stats["total_duration"],
                    "avg_duration": avg_duration,
                    "avg_rating": avg_rating
                })
        
        # Сортируем по количеству посещений (от большего к меньшему)
        cafes_stats.sort(key=lambda x: x["visit_count"], reverse=True)
        
        # Статистика по времени
        # Группируем посещения по дням недели и часам
        days_of_week = {0: "Понедельник", 1: "Вторник", 2: "Среда", 3: "Четверг", 
                        4: "Пятница", 5: "Суббота", 6: "Воскресенье"}
        
        day_stats = {day: 0 for day in range(7)}
        hour_stats = {hour: 0 for hour in range(24)}
        
        for visit in all_visits:
            # Преобразуем timestamp в день недели и час
            visit_time = time.localtime(visit.timestamp)
            day_of_week = visit_time.tm_wday  # 0-6 (понедельник-воскресенье)
            hour = visit_time.tm_hour  # 0-23
            
            day_stats[day_of_week] += 1
            hour_stats[hour] += 1
        
        # Преобразуем в списки для удобства использования в графиках
        days_data = [{"day": days_of_week[day], "count": count} for day, count in day_stats.items()]
        hours_data = [{"hour": hour, "count": count} for hour, count in hour_stats.items()]
        
        # Формируем итоговый результат
        result = {
            "success": True,
            "total_visits": total_visits,
            "total_cafes": total_cafes,
            "total_users": total_users,
            "cafes": cafes_stats,
            "days_of_week": days_data,
            "hours_of_day": hours_data
        }
        
        return result
    
    def generate_global_charts(self) -> Dict[str, str]:
        """
        Генерация графиков глобальной статистики.
        
        Returns:
            Словарь с путями к сгенерированным графикам
        """
        # Получаем глобальную статистику
        stats = self.get_global_statistics()
        
        if not stats.get("success", False):
            return {
                "success": False,
                "message": "Ошибка при получении статистики"
            }
        
        # Создаем директорию для глобальных графиков
        global_stats_dir = os.path.join(self.stats_dir, "global")
        os.makedirs(global_stats_dir, exist_ok=True)
        
        chart_paths = {}
        
        # График посещений по кофейням (топ-10)
        if stats["cafes"]:
            plt.figure(figsize=(12, 8))
            
            # Берем топ-10 кофеен по посещениям
            top_cafes = stats["cafes"][:10]
            
            cafe_names = [cafe["name"] for cafe in top_cafes]
            visit_counts = [cafe["visit_count"] for cafe in top_cafes]
            
            # Создаем горизонтальный бар-график
            bars = plt.barh(cafe_names, visit_counts, color='skyblue')
            
            # Добавляем значения на график
            for i, bar in enumerate(bars):
                plt.text(bar.get_width() + 0.3, bar.get_y() + bar.get_height()/2, 
                        str(visit_counts[i]), va='center')
            
            plt.xlabel('Количество посещений')
            plt.title('Топ-10 наиболее посещаемых кофеен')
            plt.tight_layout()
            
            # Сохраняем график
            cafes_chart_path = os.path.join(global_stats_dir, 'top_cafes.png')
            plt.savefig(cafes_chart_path)
            plt.close()
            
            chart_paths["top_cafes"] = cafes_chart_path
        
        # График посещений по дням недели
        plt.figure(figsize=(10, 6))
        
        days = [day["day"] for day in stats["days_of_week"]]
        day_counts = [day["count"] for day in stats["days_of_week"]]
        
        plt.bar(days, day_counts, color='lightgreen')
        plt.xlabel('День недели')
        plt.ylabel('Количество посещений')
        plt.title('Посещения по дням недели')
        plt.xticks(rotation=45)
        plt.tight_layout()
        
        days_chart_path = os.path.join(global_stats_dir, 'days_of_week.png')
        plt.savefig(days_chart_path)
        plt.close()
        
        chart_paths["days_of_week"] = days_chart_path
        
        # График посещений по часам
        plt.figure(figsize=(12, 6))
        
        hours = [hour["hour"] for hour in stats["hours_of_day"]]
        hour_counts = [hour["count"] for hour in stats["hours_of_day"]]
        
        plt.bar(hours, hour_counts, color='salmon')
        plt.xlabel('Час дня')
        plt.ylabel('Количество посещений')
        plt.title('Посещения по часам')
        plt.xticks(range(0, 24, 2))  # Показываем каждые 2 часа
        plt.grid(axis='y', linestyle='--', alpha=0.7)
        plt.tight_layout()
        
        hours_chart_path = os.path.join(global_stats_dir, 'hours_of_day.png')
        plt.savefig(hours_chart_path)
        plt.close()
        
        chart_paths["hours_of_day"] = hours_chart_path
        
        # Если есть оценки, создаем график средних оценок
        rated_cafes = [cafe for cafe in stats["cafes"] if cafe.get("avg_rating") is not None]
        
        if rated_cafes:
            plt.figure(figsize=(12, 8))
            
            # Берем топ-10 оцененных кофеен
            top_rated_cafes = sorted(rated_cafes, key=lambda x: x["avg_rating"], reverse=True)[:10]
            
            cafe_names = [cafe["name"] for cafe in top_rated_cafes]
            ratings = [cafe["avg_rating"] for cafe in top_rated_cafes]
            
            # Создаем горизонтальный бар-график
            bars = plt.barh(cafe_names, ratings, color='gold')
            
            # Добавляем значения на график
            for i, bar in enumerate(bars):
                plt.text(bar.get_width() + 0.1, bar.get_y() + bar.get_height()/2, 
                        f"{ratings[i]:.1f}", va='center')
            
            plt.xlabel('Средняя оценка')
            plt.title('Топ-10 кофеен по оценкам')
            plt.xlim(0, 5.5)  # Оценки от 0 до 5
            plt.tight_layout()
            
            # Сохраняем график
            ratings_chart_path = os.path.join(global_stats_dir, 'top_rated_cafes.png')
            plt.savefig(ratings_chart_path)
            plt.close()
            
            chart_paths["top_rated_cafes"] = ratings_chart_path
        
        return {
            "success": True,
            "charts": chart_paths
        }
