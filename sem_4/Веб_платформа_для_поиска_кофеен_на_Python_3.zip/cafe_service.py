"""
Сервис для работы с кофейнями.
"""
from typing import Dict, List, Any, Optional, Tuple

from src.business.models.cafe import Cafe, Category, Visit
from src.data.repositories.cafe_repository import CafeRepository
from src.external.maps_api.yandex_maps_api import YandexMapsAPI, MockYandexMapsAPI


class CafeService:
    """
    Сервис для работы с кофейнями.
    """
    def __init__(self, cafe_repository: CafeRepository = None, maps_api: YandexMapsAPI = None):
        """
        Инициализация сервиса.
        
        Args:
            cafe_repository: Репозиторий кофеен
            maps_api: API Яндекс.Карт
        """
        self.cafe_repository = cafe_repository or CafeRepository()
        self.maps_api = maps_api or MockYandexMapsAPI()  # Используем мок для демонстрации
    
    # Методы для работы с кофейнями из внешнего API
    
    def search_cafes(self, query: str = "кофейня", location: str = "Минск", 
                     radius: int = 5000, limit: int = 50) -> Tuple[bool, str, List[Cafe]]:
        """
        Поиск кофеен через API Яндекс.Карт.
        
        Args:
            query: Поисковый запрос
            location: Местоположение (город или координаты)
            radius: Радиус поиска в метрах
            limit: Максимальное количество результатов
            
        Returns:
            Кортеж (успех, сообщение, список кофеен)
        """
        success, message, cafes_data = self.maps_api.search_cafes(query, location, radius, limit)
        
        if not success:
            return False, message, []
        
        # Преобразуем данные из API в модели Cafe
        cafes = []
        for cafe_data in cafes_data:
            cafe = self.maps_api.convert_to_cafe_model(cafe_data)
            
            # Проверяем, существует ли уже кофейня с таким external_id
            existing_cafe = self.cafe_repository.get_cafe_by_external_id(cafe.external_id)
            
            if existing_cafe:
                # Если кофейня уже существует, используем её
                cafes.append(existing_cafe)
            else:
                # Иначе сохраняем новую кофейню
                created_cafe = self.cafe_repository.create_cafe(cafe)
                if created_cafe:
                    cafes.append(created_cafe)
        
        return True, f"Найдено {len(cafes)} кофеен", cafes
    
    # CRUD для пользовательских кофеен
    
    def create_cafe(self, name: str, address: str, latitude: float, longitude: float, 
                    description: str, added_by: int, categories: List[int] = None, 
                    features: Dict[str, Any] = None) -> Tuple[bool, str, Optional[Cafe]]:
        """
        Создание новой кофейни.
        
        Args:
            name: Название кофейни
            address: Адрес кофейни
            latitude: Широта
            longitude: Долгота
            description: Описание кофейни
            added_by: ID пользователя, добавившего кофейню
            categories: Список ID категорий
            features: Особенности кофейни
            
        Returns:
            Кортеж (успех, сообщение, кофейня)
        """
        # Валидация данных
        if not name or not address:
            return False, "Название и адрес кофейни должны быть указаны", None
        
        # Создаем кофейню
        cafe = Cafe(
            name=name,
            address=address,
            coordinates={"latitude": latitude, "longitude": longitude},
            description=description,
            categories=categories or [],
            added_by=added_by,
            features=features or {}
        )
        
        # Сохраняем кофейню
        created_cafe = self.cafe_repository.create_cafe(cafe)
        
        if created_cafe:
            return True, "Кофейня успешно создана", created_cafe
        
        return False, "Ошибка при создании кофейни", None
    
    def update_cafe(self, cafe_id: int, name: str = None, address: str = None, 
                    latitude: float = None, longitude: float = None, 
                    description: str = None, categories: List[int] = None, 
                    features: Dict[str, Any] = None) -> Tuple[bool, str, Optional[Cafe]]:
        """
        Обновление кофейни.
        
        Args:
            cafe_id: ID кофейни
            name: Новое название кофейни
            address: Новый адрес кофейни
            latitude: Новая широта
            longitude: Новая долгота
            description: Новое описание кофейни
            categories: Новый список ID категорий
            features: Новые особенности кофейни
            
        Returns:
            Кортеж (успех, сообщение, кофейня)
        """
        # Получаем кофейню
        cafe = self.cafe_repository.get_cafe_by_id(cafe_id)
        
        if not cafe:
            return False, "Кофейня не найдена", None
        
        # Обновляем данные
        if name is not None:
            cafe.name = name
        
        if address is not None:
            cafe.address = address
        
        if latitude is not None and longitude is not None:
            cafe.coordinates = {"latitude": latitude, "longitude": longitude}
        
        if description is not None:
            cafe.description = description
        
        if categories is not None:
            cafe.categories = categories
        
        if features is not None:
            cafe.features = features
        
        # Сохраняем изменения
        updated_cafe = self.cafe_repository.update_cafe(cafe)
        
        if updated_cafe:
            return True, "Кофейня успешно обновлена", updated_cafe
        
        return False, "Ошибка при обновлении кофейни", None
    
    def delete_cafe(self, cafe_id: int) -> Tuple[bool, str]:
        """
        Удаление кофейни.
        
        Args:
            cafe_id: ID кофейни
            
        Returns:
            Кортеж (успех, сообщение)
        """
        # Проверяем, существует ли кофейня
        cafe = self.cafe_repository.get_cafe_by_id(cafe_id)
        
        if not cafe:
            return False, "Кофейня не найдена"
        
        # Удаляем кофейню
        if self.cafe_repository.delete_cafe(cafe_id):
            return True, "Кофейня успешно удалена"
        
        return False, "Ошибка при удалении кофейни"
    
    def get_cafe(self, cafe_id: int) -> Optional[Cafe]:
        """
        Получение кофейни по ID.
        
        Args:
            cafe_id: ID кофейни
            
        Returns:
            Объект кофейни или None, если кофейня не найдена
        """
        return self.cafe_repository.get_cafe_by_id(cafe_id)
    
    def get_all_cafes(self) -> List[Cafe]:
        """
        Получение всех кофеен.
        
        Returns:
            Список кофеен
        """
        return self.cafe_repository.get_all_cafes()
    
    def get_cafes_by_user(self, user_id: int) -> List[Cafe]:
        """
        Получение кофеен, добавленных пользователем.
        
        Args:
            user_id: ID пользователя
            
        Returns:
            Список кофеен
        """
        return self.cafe_repository.get_cafes_by_user(user_id)
    
    def get_nearby_cafes(self, latitude: float, longitude: float, radius: float = 1.0) -> List[Cafe]:
        """
        Получение ближайших кофеен.
        
        Args:
            latitude: Широта
            longitude: Долгота
            radius: Радиус поиска в километрах
            
        Returns:
            Список кофеен
        """
        return self.cafe_repository.get_nearby_cafes(latitude, longitude, radius)
    
    # Методы для работы с категориями
    
    def create_category(self, name: str, description: str, created_by: int) -> Tuple[bool, str, Optional[Category]]:
        """
        Создание новой категории.
        
        Args:
            name: Название категории
            description: Описание категории
            created_by: ID пользователя, создавшего категорию
            
        Returns:
            Кортеж (успех, сообщение, категория)
        """
        # Валидация данных
        if not name:
            return False, "Название категории должно быть указано", None
        
        # Проверяем, не существует ли уже категория с таким именем
        existing_category = self.cafe_repository.get_category_by_name(name)
        
        if existing_category:
            return False, f"Категория с названием '{name}' уже существует", None
        
        # Создаем категорию
        category = Category(
            name=name,
            description=description,
            created_by=created_by
        )
        
        # Сохраняем категорию
        created_category = self.cafe_repository.create_category(category)
        
        if created_category:
            return True, "Категория успешно создана", created_category
        
        return False, "Ошибка при создании категории", None
    
    def update_category(self, category_id: int, name: str = None, description: str = None) -> Tuple[bool, str, Optional[Category]]:
        """
        Обновление категории.
        
        Args:
            category_id: ID категории
            name: Новое название категории
            description: Новое описание категории
            
        Returns:
            Кортеж (успех, сообщение, категория)
        """
        # Получаем категорию
        category = self.cafe_repository.get_category_by_id(category_id)
        
        if not category:
            return False, "Категория не найдена", None
        
        # Обновляем данные
        if name is not None:
            # Проверяем, не существует ли уже категория с таким именем
            if name != category.name:
                existing_category = self.cafe_repository.get_category_by_name(name)
                
                if existing_category:
                    return False, f"Категория с названием '{name}' уже существует", None
            
            category.name = name
        
        if description is not None:
            category.description = description
        
        # Сохраняем изменения
        updated_category = self.cafe_repository.update_category(category)
        
        if updated_category:
            return True, "Категория успешно обновлена", updated_category
        
        return False, "Ошибка при обновлении категории", None
    
    def delete_category(self, category_id: int) -> Tuple[bool, str]:
        """
        Удаление категории.
        
        Args:
            category_id: ID категории
            
        Returns:
            Кортеж (успех, сообщение)
        """
        # Проверяем, существует ли категория
        category = self.cafe_repository.get_category_by_id(category_id)
        
        if not category:
            return False, "Категория не найдена"
        
        # Удаляем категорию
        if self.cafe_repository.delete_category(category_id):
            return True, "Категория успешно удалена"
        
        return False, "Ошибка при удалении категории"
    
    def get_category(self, category_id: int) -> Optional[Category]:
        """
        Получение категории по ID.
        
        Args:
            category_id: ID категории
            
        Returns:
            Объект категории или None, если категория не найдена
        """
        return self.cafe_repository.get_category_by_id(category_id)
    
    def get_all_categories(self) -> List[Category]:
        """
        Получение всех категорий.
        
        Returns:
            Список категорий
        """
        return self.cafe_repository.get_all_categories()
    
    def get_categories_by_user(self, user_id: int) -> List[Category]:
        """
        Получение категорий, созданных пользователем.
        
        Args:
            user_id: ID пользователя
            
        Returns:
            Список категорий
        """
        return self.cafe_repository.get_categories_by_user(user_id)
    
    # Методы для работы с избранным
    
    def add_cafe_to_favorites(self, user_id: int, cafe_id: int) -> Tuple[bool, str]:
        """
        Добавление кофейни в избранное пользователя.
        
        Args:
            user_id: ID пользователя
            cafe_id: ID кофейни
            
        Returns:
            Кортеж (успех, сообщение)
        """
        from src.data.repositories.user_repository import UserRepository
        user_repository = UserRepository()
        
        # Получаем пользователя
        user = user_repository.get_user_by_id(user_id)
        
        if not user:
            return False, "Пользователь не найден"
        
        # Получаем кофейню
        cafe = self.cafe_repository.get_cafe_by_id(cafe_id)
        
        if not cafe:
            return False, "Кофейня не найдена"
        
        # Добавляем кофейню в избранное
        if user.add_favorite_cafe(cafe_id):
            # Сохраняем изменения
            if user_repository.update_user(user):
                return True, "Кофейня успешно добавлена в избранное"
        
        return False, "Кофейня уже в избранном"
    
    def remove_cafe_from_favorites(self, user_id: int, cafe_id: int) -> Tuple[bool, str]:
        """
        Удаление кофейни из избранного пользователя.
        
        Args:
            user_id: ID пользователя
            cafe_id: ID кофейни
            
        Returns:
            Кортеж (успех, сообщение)
        """
        from src.data.repositories.user_repository import UserRepository
        user_repository = UserRepository()
        
        # Получаем пользователя
        user = user_repository.get_user_by_id(user_id)
        
        if not user:
            return False, "Пользователь не найден"
        
        # Удаляем кофейню из избранного
        if user.remove_favorite_cafe(cafe_id):
            # Сохраняем изменения
            if user_repository.update_user(user):
                return True, "Кофейня успешно удалена из избранного"
        
        return False, "Кофейня не найдена в избранном"
    
    def get_favorite_cafes(self, user_id: int) -> List[Cafe]:
        """
        Получение избранных кофеен пользователя.
        
        Args:
            user_id: ID пользователя
            
        Returns:
            Список кофеен
        """
        from src.data.repositories.user_repository import UserRepository
        user_repository = UserRepository()
        
        # Получаем пользователя
        user = user_repository.get_user_by_id(user_id)
        
        if not user:
            return []
        
        # Получаем избранные кофейни
        favorite_cafes = []
        for cafe_id in user.favorite_cafes:
            cafe = self.cafe_repository.get_cafe_by_id(cafe_id)
            if cafe:
                favorite_cafes.append(cafe)
        
        return favorite_cafes
    
    def get_favorite_cafes_by_category(self, user_id: int, category_id: int) -> List[Cafe]:
        """
        Получение избранных кофеен пользователя по категории.
        
        Args:
            user_id: ID пользователя
            category_id: ID категории
            
        Returns:
            Список кофеен
        """
        # Получаем все избранные кофейни пользователя
        favorite_cafes = self.get_favorite_cafes(user_id)
        
        # Фильтруем по категории
        return [cafe for cafe in favorite_cafes if category_id in cafe.categories]
    
    # Методы для работы с посещениями
    
    def record_visit(self, user_id: int, cafe_id: int, duration: int = 0, rating: float = None) -> Tuple[bool, str, Optional[Visit]]:
        """
        Запись посещения кофейни.
        
        Args:
            user_id: ID пользователя
            cafe_id: ID кофейни
            duration: Продолжительность посещения в минутах
            rating: Оценка кофейни
            
        Returns:
            Кортеж (успех, сообщение, посещение)
        """
        # Проверяем, существует ли кофейня
        cafe = self.cafe_repository.get_cafe_by_id(cafe_id)
        
        if not cafe:
            return False, "Кофейня не найдена", None
        
        # Создаем посещение
        visit = Visit(
            user_id=user_id,
            cafe_id=cafe_id,
            duration=duration,
            rating=rating
        )
        
        # Сохраняем посещение
        created_visit = self.cafe_repository.create_visit(visit)
        
        if created_visit:
            # Если указана оценка, обновляем рейтинг кофейни
            if rating is not None:
                # Получаем все посещения кофейни с оценками
                visits = self.cafe_repository.get_visits_by_cafe(cafe_id)
                rated_visits = [v for v in visits if v.rating is not None]
                
                if rated_visits:
                    # Вычисляем средний рейтинг
                    avg_rating = sum(v.rating for v in rated_visits) / len(rated_visits)
                    
                    # Обновляем рейтинг кофейни
                    cafe.update_rating(avg_rating)
                    self.cafe_repository.update_cafe(cafe)
            
            return True, "Посещение успешно записано", created_visit
        
        return False, "Ошибка при записи посещения", None
    
    def get_visits_by_user(self, user_id: int) -> List[Visit]:
        """
        Получение посещений пользователя.
        
        Args:
            user_id: ID пользователя
            
        Returns:
            Список посещений
        """
        return self.cafe_repository.get_visits_by_user(user_id)
    
    def get_visits_by_cafe(self, cafe_id: int) -> List[Visit]:
        """
        Получение посещений кофейни.
        
        Args:
            cafe_id: ID кофейни
            
        Returns:
            Список посещений
        """
        return self.cafe_repository.get_visits_by_cafe(cafe_id)
    
    def get_visit_statistics(self, user_id: int) -> Dict[str, Any]:
        """
        Получение статистики посещений пользователя.
        
        Args:
            user_id: ID пользователя
            
        Returns:
            Словарь со статистикой
        """
        # Получаем все посещения пользователя
        visits = self.cafe_repository.get_visits_by_user(user_id)
        
        # Получаем избранные кофейни пользователя
        favorite_cafes = self.get_favorite_cafes(user_id)
        favorite_cafe_ids = [cafe.id for cafe in favorite_cafes]
        
        # Статистика по посещениям
        total_visits = len(visits)
        favorite_visits = len([v for v in visits if v.cafe_id in favorite_cafe_ids])
        rated_visits = len([v for v in visits if v.rating is not None])
        
        # Статистика по кофейням
        cafe_visits = {}
        for visit in visits:
            cafe_id = visit.cafe_id
            if cafe_id not in cafe_visits:
                cafe_visits[cafe_id] = 0
            cafe_visits[cafe_id] += 1
        
        # Сортируем кофейни по количеству посещений
        most_visited = sorted(cafe_visits.items(), key=lambda x: x[1], reverse=True)
        
        # Формируем результат
        result = {
            "total_visits": total_visits,
            "favorite_visits": favorite_visits,
            "rated_visits": rated_visits,
            "most_visited": []
        }
        
        # Добавляем информацию о наиболее посещаемых кофейнях
        for cafe_id, visit_count in most_visited[:5]:  # Топ-5 кофеен
            cafe = self.cafe_repository.get_cafe_by_id(cafe_id)
            if cafe:
                result["most_visited"].append({
                    "cafe_id": cafe_id,
                    "name": cafe.name,
                    "visit_count": visit_count,
                    "is_favorite": cafe_id in favorite_cafe_ids
                })
        
        return result
