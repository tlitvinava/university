"""
Модель пользователя.
"""
from typing import Dict, List, Any, Optional
import hashlib
import time
import uuid


class User:
    """
    Класс, представляющий пользователя системы.
    """
    def __init__(
        self,
        id: Optional[int] = None,
        username: str = "",
        email: str = "",
        password_hash: str = "",
        friends: List[int] = None,
        favorite_cafes: List[int] = None,
        location: Dict[str, float] = None
    ):
        """
        Инициализация пользователя.
        
        Args:
            id: Уникальный идентификатор пользователя
            username: Имя пользователя
            email: Электронная почта
            password_hash: Хеш пароля
            friends: Список ID друзей
            favorite_cafes: Список ID избранных кофеен
            location: Текущее местоположение (широта, долгота)
        """
        self.id = id
        self.username = username
        self.email = email
        self.password_hash = password_hash
        self.friends = friends or []
        self.favorite_cafes = favorite_cafes or []
        self.location = location or {"latitude": 0.0, "longitude": 0.0}
        self.created_at = int(time.time())
        self.last_login = int(time.time())
    
    @staticmethod
    def hash_password(password: str) -> str:
        """
        Хеширование пароля.
        
        Args:
            password: Пароль в открытом виде
            
        Returns:
            Хеш пароля
        """
        # В реальном проекте следует использовать более надежные методы хеширования
        # например, bcrypt или Argon2
        salt = uuid.uuid4().hex
        return hashlib.sha256(salt.encode() + password.encode()).hexdigest() + ':' + salt
    
    @staticmethod
    def verify_password(stored_password: str, provided_password: str) -> bool:
        """
        Проверка пароля.
        
        Args:
            stored_password: Сохраненный хеш пароля
            provided_password: Предоставленный пароль
            
        Returns:
            True, если пароль верный, иначе False
        """
        # В реальном проекте следует использовать более надежные методы проверки
        try:
            password_hash, salt = stored_password.split(':')
            return password_hash == hashlib.sha256(salt.encode() + provided_password.encode()).hexdigest()
        except Exception:
            return False
    
    def to_dict(self) -> Dict[str, Any]:
        """
        Преобразование пользователя в словарь.
        
        Returns:
            Словарь с данными пользователя
        """
        return {
            "id": self.id,
            "username": self.username,
            "email": self.email,
            "password_hash": self.password_hash,
            "friends": self.friends,
            "favorite_cafes": self.favorite_cafes,
            "location": self.location,
            "created_at": self.created_at,
            "last_login": self.last_login
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'User':
        """
        Создание пользователя из словаря.
        
        Args:
            data: Словарь с данными пользователя
            
        Returns:
            Объект пользователя
        """
        user = cls(
            id=data.get("id"),
            username=data.get("username", ""),
            email=data.get("email", ""),
            password_hash=data.get("password_hash", ""),
            friends=data.get("friends", []),
            favorite_cafes=data.get("favorite_cafes", []),
            location=data.get("location", {"latitude": 0.0, "longitude": 0.0})
        )
        user.created_at = data.get("created_at", int(time.time()))
        user.last_login = data.get("last_login", int(time.time()))
        return user
    
    def add_friend(self, friend_id: int) -> bool:
        """
        Добавление друга.
        
        Args:
            friend_id: ID друга
            
        Returns:
            True, если друг успешно добавлен, иначе False
        """
        if friend_id == self.id:
            return False
        
        if friend_id not in self.friends:
            self.friends.append(friend_id)
            return True
        
        return False
    
    def remove_friend(self, friend_id: int) -> bool:
        """
        Удаление друга.
        
        Args:
            friend_id: ID друга
            
        Returns:
            True, если друг успешно удален, иначе False
        """
        if friend_id in self.friends:
            self.friends.remove(friend_id)
            return True
        
        return False
    
    def add_favorite_cafe(self, cafe_id: int) -> bool:
        """
        Добавление кофейни в избранное.
        
        Args:
            cafe_id: ID кофейни
            
        Returns:
            True, если кофейня успешно добавлена, иначе False
        """
        if cafe_id not in self.favorite_cafes:
            self.favorite_cafes.append(cafe_id)
            return True
        
        return False
    
    def remove_favorite_cafe(self, cafe_id: int) -> bool:
        """
        Удаление кофейни из избранного.
        
        Args:
            cafe_id: ID кофейни
            
        Returns:
            True, если кофейня успешно удалена, иначе False
        """
        if cafe_id in self.favorite_cafes:
            self.favorite_cafes.remove(cafe_id)
            return True
        
        return False
    
    def update_location(self, latitude: float, longitude: float) -> None:
        """
        Обновление местоположения пользователя.
        
        Args:
            latitude: Широта
            longitude: Долгота
        """
        self.location = {
            "latitude": latitude,
            "longitude": longitude
        }
