"""
JSON плагин для сериализации/десериализации.
"""
import os
import json
from typing import Any, Dict, List, Optional


class JSONSerializer:
    """
    Класс для сериализации/десериализации данных в формате JSON.
    """
    
    def serialize(self, data: Any) -> str:
        """
        Сериализация данных в JSON-строку.
        
        Args:
            data: Данные для сериализации
            
        Returns:
            JSON-строка
        """
        try:
            return json.dumps(data, ensure_ascii=False, indent=2)
        except Exception as e:
            print(f"Ошибка сериализации JSON: {str(e)}")
            return ""
    
    def deserialize(self, data_str: str) -> Any:
        """
        Десериализация JSON-строки в данные.
        
        Args:
            data_str: JSON-строка для десериализации
            
        Returns:
            Десериализованные данные
        """
        try:
            return json.loads(data_str)
        except Exception as e:
            print(f"Ошибка десериализации JSON: {str(e)}")
            return None
    
    def serialize_to_file(self, data: Any, file_path: str) -> bool:
        """
        Сериализация данных в JSON-файл.
        
        Args:
            data: Данные для сериализации
            file_path: Путь к файлу
            
        Returns:
            True, если сериализация успешна, иначе False
        """
        try:
            # Создаем директорию, если она не существует
            os.makedirs(os.path.dirname(os.path.abspath(file_path)), exist_ok=True)
            
            with open(file_path, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            
            return True
        except Exception as e:
            print(f"Ошибка сериализации в файл: {str(e)}")
            return False
    
    def deserialize_from_file(self, file_path: str) -> Any:
        """
        Десериализация данных из JSON-файла.
        
        Args:
            file_path: Путь к файлу
            
        Returns:
            Десериализованные данные
        """
        try:
            if not os.path.exists(file_path):
                print(f"Файл не существует: {file_path}")
                return None
            
            with open(file_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            print(f"Ошибка десериализации из файла: {str(e)}")
            return None
