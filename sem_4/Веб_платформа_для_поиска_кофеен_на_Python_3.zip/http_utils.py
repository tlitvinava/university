"""
Утилиты для работы с HTTP-запросами и ответами.
"""
import json
import urllib.parse
from typing import Dict, Any, List, Tuple, Optional, Union


def parse_query_string(query_string: str) -> Dict[str, str]:
    """
    Разбор строки запроса в словарь параметров.
    
    Args:
        query_string: Строка запроса
        
    Returns:
        Словарь параметров запроса
    """
    if not query_string:
        return {}
    
    return {k: v[0] for k, v in urllib.parse.parse_qs(query_string).items()}


def parse_multipart_form_data(environ: Dict[str, Any]) -> Dict[str, Any]:
    """
    Разбор данных формы multipart/form-data.
    
    Args:
        environ: Окружение WSGI
        
    Returns:
        Словарь с данными формы
    """
    # Упрощенная реализация для демонстрации
    # В реальном проекте нужно использовать более надежную библиотеку
    content_length = int(environ.get('CONTENT_LENGTH', 0))
    if not content_length:
        return {}
    
    request_body = environ['wsgi.input'].read(content_length)
    # Простая реализация для демонстрации
    # В реальном проекте нужно правильно обрабатывать multipart/form-data
    return {}


def parse_json_body(environ: Dict[str, Any]) -> Dict[str, Any]:
    """
    Разбор JSON-данных из тела запроса.
    
    Args:
        environ: Окружение WSGI
        
    Returns:
        Словарь с данными из JSON
    """
    content_length = int(environ.get('CONTENT_LENGTH', 0))
    if not content_length:
        return {}
    
    request_body = environ['wsgi.input'].read(content_length)
    try:
        return json.loads(request_body)
    except json.JSONDecodeError:
        return {}


def parse_request_body(environ: Dict[str, Any]) -> Dict[str, Any]:
    """
    Разбор тела запроса в зависимости от Content-Type.
    
    Args:
        environ: Окружение WSGI
        
    Returns:
        Словарь с данными из тела запроса
    """
    content_type = environ.get('CONTENT_TYPE', '')
    
    if 'application/json' in content_type:
        return parse_json_body(environ)
    elif 'multipart/form-data' in content_type:
        return parse_multipart_form_data(environ)
    elif 'application/x-www-form-urlencoded' in content_type:
        content_length = int(environ.get('CONTENT_LENGTH', 0))
        if not content_length:
            return {}
        request_body = environ['wsgi.input'].read(content_length).decode('utf-8')
        return {k: v[0] for k, v in urllib.parse.parse_qs(request_body).items()}
    
    return {}


def create_response(status: str, headers: List[Tuple[str, str]], body: Union[str, bytes]) -> Tuple[str, List[Tuple[str, str]], Union[List[bytes], List[str]]]:
    """
    Создание HTTP-ответа.
    
    Args:
        status: Статус ответа (например, '200 OK')
        headers: Заголовки ответа
        body: Тело ответа
        
    Returns:
        Кортеж (статус, заголовки, тело) для WSGI-сервера
    """
    if isinstance(body, str):
        body = body.encode('utf-8')
    
    return status, headers, [body]


def json_response(data: Any, status: str = '200 OK') -> Tuple[str, List[Tuple[str, str]], List[bytes]]:
    """
    Создание JSON-ответа.
    
    Args:
        data: Данные для сериализации в JSON
        status: Статус ответа
        
    Returns:
        Кортеж (статус, заголовки, тело) для WSGI-сервера
    """
    body = json.dumps(data).encode('utf-8')
    headers = [
        ('Content-Type', 'application/json'),
        ('Content-Length', str(len(body)))
    ]
    
    return status, headers, [body]


def html_response(html: str, status: str = '200 OK') -> Tuple[str, List[Tuple[str, str]], List[bytes]]:
    """
    Создание HTML-ответа.
    
    Args:
        html: HTML-содержимое
        status: Статус ответа
        
    Returns:
        Кортеж (статус, заголовки, тело) для WSGI-сервера
    """
    body = html.encode('utf-8')
    headers = [
        ('Content-Type', 'text/html; charset=utf-8'),
        ('Content-Length', str(len(body)))
    ]
    
    return status, headers, [body]


def redirect_response(location: str, status: str = '302 Found') -> Tuple[str, List[Tuple[str, str]], List[bytes]]:
    """
    Создание ответа с перенаправлением.
    
    Args:
        location: URL для перенаправления
        status: Статус ответа
        
    Returns:
        Кортеж (статус, заголовки, тело) для WSGI-сервера
    """
    body = f'<html><body>Redirecting to <a href="{location}">{location}</a></body></html>'.encode('utf-8')
    headers = [
        ('Location', location),
        ('Content-Type', 'text/html; charset=utf-8'),
        ('Content-Length', str(len(body)))
    ]
    
    return status, headers, [body]


def not_found_response() -> Tuple[str, List[Tuple[str, str]], List[bytes]]:
    """
    Создание ответа 404 Not Found.
    
    Returns:
        Кортеж (статус, заголовки, тело) для WSGI-сервера
    """
    body = '<html><body><h1>404 Not Found</h1></body></html>'.encode('utf-8')
    headers = [
        ('Content-Type', 'text/html; charset=utf-8'),
        ('Content-Length', str(len(body)))
    ]
    
    return '404 Not Found', headers, [body]


def method_not_allowed_response() -> Tuple[str, List[Tuple[str, str]], List[bytes]]:
    """
    Создание ответа 405 Method Not Allowed.
    
    Returns:
        Кортеж (статус, заголовки, тело) для WSGI-сервера
    """
    body = '<html><body><h1>405 Method Not Allowed</h1></body></html>'.encode('utf-8')
    headers = [
        ('Content-Type', 'text/html; charset=utf-8'),
        ('Content-Length', str(len(body)))
    ]
    
    return '405 Method Not Allowed', headers, [body]


def server_error_response() -> Tuple[str, List[Tuple[str, str]], List[bytes]]:
    """
    Создание ответа 500 Internal Server Error.
    
    Returns:
        Кортеж (статус, заголовки, тело) для WSGI-сервера
    """
    body = '<html><body><h1>500 Internal Server Error</h1></body></html>'.encode('utf-8')
    headers = [
        ('Content-Type', 'text/html; charset=utf-8'),
        ('Content-Length', str(len(body)))
    ]
    
    return '500 Internal Server Error', headers, [body]
