"""
Базовый модуль для создания плагина сериализации/десериализации.
"""
from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional


class SerializerPlugin(ABC):
    """
    Абстрактный базовый класс для плагинов сериализации/десериализации.
    """
    
    @abstractmethod
    def serialize(self, data: Any) -> str:
        """
        Сериализация данных в строку.
        
        Args:
            data: Данные для сериализации
            
        Returns:
            Сериализованная строка
        """
        pass
    
    @abstractmethod
    def deserialize(self, data_str: str) -> Any:
        """
        Десериализация строки в данные.
        
        Args:
            data_str: Строка для десериализации
            
        Returns:
            Десериализованные данные
        """
        pass
    
    @abstractmethod
    def serialize_to_file(self, data: Any, file_path: str) -> bool:
        """
        Сериализация данных в файл.
        
        Args:
            data: Данные для сериализации
            file_path: Путь к файлу
            
        Returns:
            True, если сериализация успешна, иначе False
        """
        pass
    
    @abstractmethod
    def deserialize_from_file(self, file_path: str) -> Any:
        """
        Десериализация данных из файла.
        
        Args:
            file_path: Путь к файлу
            
        Returns:
            Десериализованные данные
        """
        pass
