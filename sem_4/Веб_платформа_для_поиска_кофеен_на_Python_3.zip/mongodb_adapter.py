"""
Адаптер для интеграции MongoDB с репозиториями.
"""
from typing import Dict, List, Any, Optional, Tuple

from src.external.database.mongodb_connector import MongoDBConnector
from src.business.models.user import User
from src.business.models.cafe import Cafe, Category, Visit


class MongoDBAdapter:
    """
    Адаптер для интеграции MongoDB с репозиториями.
    """
    
    def __init__(self, connection_string: str = None, db_name: str = "coffee_finder"):
        """
        Инициализация адаптера.
        
        Args:
            connection_string: Строка подключения к MongoDB
            db_name: Имя базы данных
        """
        self.db = MongoDBConnector(connection_string, db_name)
        
        # Создаем индексы для коллекций
        self._create_indexes()
    
    def _create_indexes(self) -> None:
        """
        Создание индексов для коллекций.
        """
        # Индекс для пользователей по username
        self.db.create_index("users", [("username", 1)], unique=True)
        
        # Индекс для кофеен по external_id
        self.db.create_index("cafes", [("external_id", 1)], unique=True)
        
        # Индекс для категорий по имени
        self.db.create_index("categories", [("name", 1)], unique=True)
        
        # Индексы для посещений
        self.db.create_index("visits", [("user_id", 1)])
        self.db.create_index("visits", [("cafe_id", 1)])
        self.db.create_index("visits", [("timestamp", -1)])
    
    # Методы для работы с пользователями
    
    def create_user(self, user: User) -> Optional[User]:
        """
        Создание пользователя в MongoDB.
        
        Args:
            user: Объект пользователя
            
        Returns:
            Созданный пользователь или None в случае ошибки
        """
        # Преобразуем пользователя в словарь
        user_dict = user.to_dict()
        
        # Удаляем id, так как MongoDB создаст свой
        if "id" in user_dict:
            del user_dict["id"]
        
        # Создаем документ
        user_id = self.db.create_document("users", user_dict)
        
        if user_id:
            # Получаем созданного пользователя
            user_dict = self.db.read_document("users", user_id)
            
            if user_dict:
                # Преобразуем _id в id
                user_dict["id"] = user_dict.pop("_id")
                
                # Создаем объект пользователя
                return User.from_dict(user_dict)
        
        return None
    
    def update_user(self, user: User) -> bool:
        """
        Обновление пользователя в MongoDB.
        
        Args:
            user: Объект пользователя
            
        Returns:
            True, если обновление успешно, иначе False
        """
        if not user.id:
            return False
        
        # Преобразуем пользователя в словарь
        user_dict = user.to_dict()
        
        # Удаляем id, так как MongoDB использует _id
        if "id" in user_dict:
            del user_dict["id"]
        
        # Обновляем документ
        return self.db.update_document("users", user.id, user_dict)
    
    def delete_user(self, user_id: str) -> bool:
        """
        Удаление пользователя из MongoDB.
        
        Args:
            user_id: ID пользователя
            
        Returns:
            True, если удаление успешно, иначе False
        """
        return self.db.delete_document("users", user_id)
    
    def get_user_by_id(self, user_id: str) -> Optional[User]:
        """
        Получение пользователя по ID из MongoDB.
        
        Args:
            user_id: ID пользователя
            
        Returns:
            Объект пользователя или None, если пользователь не найден
        """
        user_dict = self.db.read_document("users", user_id)
        
        if user_dict:
            # Преобразуем _id в id
            user_dict["id"] = user_dict.pop("_id")
            
            # Создаем объект пользователя
            return User.from_dict(user_dict)
        
        return None
    
    def get_user_by_username(self, username: str) -> Optional[User]:
        """
        Получение пользователя по имени пользователя из MongoDB.
        
        Args:
            username: Имя пользователя
            
        Returns:
            Объект пользователя или None, если пользователь не найден
        """
        users = self.db.find_documents("users", {"username": username}, limit=1)
        
        if users:
            # Преобразуем _id в id
            users[0]["id"] = users[0].pop("_id")
            
            # Создаем объект пользователя
            return User.from_dict(users[0])
        
        return None
    
    def get_all_users(self) -> List[User]:
        """
        Получение всех пользователей из MongoDB.
        
        Returns:
            Список пользователей
        """
        users_dict = self.db.find_documents("users")
        
        users = []
        for user_dict in users_dict:
            # Преобразуем _id в id
            user_dict["id"] = user_dict.pop("_id")
            
            # Создаем объект пользователя
            users.append(User.from_dict(user_dict))
        
        return users
    
    # Методы для работы с кофейнями
    
    def create_cafe(self, cafe: Cafe) -> Optional[Cafe]:
        """
        Создание кофейни в MongoDB.
        
        Args:
            cafe: Объект кофейни
            
        Returns:
            Созданная кофейня или None в случае ошибки
        """
        # Преобразуем кофейню в словарь
        cafe_dict = cafe.to_dict()
        
        # Удаляем id, так как MongoDB создаст свой
        if "id" in cafe_dict:
            del cafe_dict["id"]
        
        # Создаем документ
        cafe_id = self.db.create_document("cafes", cafe_dict)
        
        if cafe_id:
            # Получаем созданную кофейню
            cafe_dict = self.db.read_document("cafes", cafe_id)
            
            if cafe_dict:
                # Преобразуем _id в id
                cafe_dict["id"] = cafe_dict.pop("_id")
                
                # Создаем объект кофейни
                return Cafe.from_dict(cafe_dict)
        
        return None
    
    def update_cafe(self, cafe: Cafe) -> bool:
        """
        Обновление кофейни в MongoDB.
        
        Args:
            cafe: Объект кофейни
            
        Returns:
            True, если обновление успешно, иначе False
        """
        if not cafe.id:
            return False
        
        # Преобразуем кофейню в словарь
        cafe_dict = cafe.to_dict()
        
        # Удаляем id, так как MongoDB использует _id
        if "id" in cafe_dict:
            del cafe_dict["id"]
        
        # Обновляем документ
        return self.db.update_document("cafes", cafe.id, cafe_dict)
    
    def delete_cafe(self, cafe_id: str) -> bool:
        """
        Удаление кофейни из MongoDB.
        
        Args:
            cafe_id: ID кофейни
            
        Returns:
            True, если удаление успешно, иначе False
        """
        return self.db.delete_document("cafes", cafe_id)
    
    def get_cafe_by_id(self, cafe_id: str) -> Optional[Cafe]:
        """
        Получение кофейни по ID из MongoDB.
        
        Args:
            cafe_id: ID кофейни
            
        Returns:
            Объект кофейни или None, если кофейня не найдена
        """
        cafe_dict = self.db.read_document("cafes", cafe_id)
        
        if cafe_dict:
            # Преобразуем _id в id
            cafe_dict["id"] = cafe_dict.pop("_id")
            
            # Создаем объект кофейни
            return Cafe.from_dict(cafe_dict)
        
        return None
    
    def get_cafe_by_external_id(self, external_id: str) -> Optional[Cafe]:
        """
        Получение кофейни по внешнему ID из MongoDB.
        
        Args:
            external_id: Внешний ID кофейни
            
        Returns:
            Объект кофейни или None, если кофейня не найдена
        """
        cafes = self.db.find_documents("cafes", {"external_id": external_id}, limit=1)
        
        if cafes:
            # Преобразуем _id в id
            cafes[0]["id"] = cafes[0].pop("_id")
            
            # Создаем объект кофейни
            return Cafe.from_dict(cafes[0])
        
        return None
    
    def get_all_cafes(self) -> List[Cafe]:
        """
        Получение всех кофеен из MongoDB.
        
        Returns:
            Список кофеен
        """
        cafes_dict = self.db.find_documents("cafes")
        
        cafes = []
        for cafe_dict in cafes_dict:
            # Преобразуем _id в id
            cafe_dict["id"] = cafe_dict.pop("_id")
            
            # Создаем объект кофейни
            cafes.append(Cafe.from_dict(cafe_dict))
        
        return cafes
    
    def get_cafes_by_user(self, user_id: str) -> List[Cafe]:
        """
        Получение кофеен, добавленных пользователем, из MongoDB.
        
        Args:
            user_id: ID пользователя
            
        Returns:
            Список кофеен
        """
        cafes_dict = self.db.find_documents("cafes", {"added_by": user_id})
        
        cafes = []
        for cafe_dict in cafes_dict:
            # Преобразуем _id в id
            cafe_dict["id"] = cafe_dict.pop("_id")
            
            # Создаем объект кофейни
            cafes.append(Cafe.from_dict(cafe_dict))
        
        return cafes
    
    def get_cafes_by_category(self, category_id: str) -> List[Cafe]:
        """
        Получение кофеен по категории из MongoDB.
        
        Args:
            category_id: ID категории
            
        Returns:
            Список кофеен
        """
        cafes_dict = self.db.find_documents("cafes", {"categories": category_id})
        
        cafes = []
        for cafe_dict in cafes_dict:
            # Преобразуем _id в id
            cafe_dict["id"] = cafe_dict.pop("_id")
            
            # Создаем объект кофейни
            cafes.append(Cafe.from_dict(cafe_dict))
        
        return cafes
    
    def get_nearby_cafes(self, latitude: float, longitude: float, radius: float = 1.0) -> List[Cafe]:
        """
        Получение ближайших кофеен из MongoDB.
        
        Args:
            latitude: Широта
            longitude: Долгота
            radius: Радиус поиска в километрах
            
        Returns:
            Список кофеен
        """
        # В MongoDB для геопространственных запросов нужно использовать GeoJSON и индексы
        # Здесь мы используем простой подход с фильтрацией на стороне клиента
        
        cafes = self.get_all_cafes()
        nearby_cafes = []
        
        for cafe in cafes:
            # Простая проверка расстояния (приближение)
            cafe_lat = cafe.coordinates.get('latitude', 0)
            cafe_lon = cafe.coordinates.get('longitude', 0)
            
            # Приближенное расстояние в километрах
            # В реальном проекте следует использовать более точную формулу
            distance = ((cafe_lat - latitude) ** 2 + (cafe_lon - longitude) ** 2) ** 0.5 * 111
            
            if distance <= radius:
                nearby_cafes.append(cafe)
        
        return nearby_cafes
    
    # Методы для работы с категориями
    
    def create_category(self, category: Category) -> Optional[Category]:
        """
        Создание категории в MongoDB.
        
        Args:
            category: Объект категории
            
        Returns:
            Созданная категория или None в случае ошибки
        """
        # Преобразуем категорию в словарь
        category_dict = category.to_dict()
        
        # Удаляем id, так как MongoDB создаст свой
        if "id" in category_dict:
            del category_dict["id"]
        
        # Создаем документ
        category_id = self.db.create_document("categories", category_dict)
        
        if category_id:
            # Получаем созданную категорию
            category_dict = self.db.read_document("categories", category_id)
            
            if category_dict:
                # Преобразуем _id в id
                category_dict["id"] = category_dict.pop("_id")
                
                # Создаем объект категории
                return Category.from_dict(category_dict)
        
        return None
    
    def update_category(self, category: Category) -> bool:
        """
        Обновление категории в MongoDB.
        
        Args:
            category: Объект категории
            
        Returns:
            True, если обновление успешно, иначе False
        """
        if not category.id:
            return False
        
        # Преобразуем категорию в словарь
        category_dict = category.to_dict()
        
        # Удаляем id, так как MongoDB использует _id
        if "id" in category_dict:
            del category_dict["id"]
        
        # Обновляем документ
        return self.db.update_document("categories", category.id, category_dict)
    
    def delete_category(self, category_id: str) -> bool:
        """
        Удаление категории из MongoDB.
        
        Args:
            category_id: ID категории
            
        Returns:
            True, если удаление успешно, иначе False
        """
        return self.db.delete_document("categories", category_id)
    
    def get_category_by_id(self, category_id: str) -> Optional[Category]:
        """
        Получение категории по ID из MongoDB.
        
        Args:
            category_id: ID категории
            
        Returns:
            Объект категории или None, если категория не найдена
        """
        category_dict = self.db.read_document("categories", category_id)
        
        if category_dict:
            # Преобразуем _id в id
            category_dict["id"] = category_dict.pop("_id")
            
            # Создаем объект категории
            return Category.from_dict(category_dict)
        
        return None
    
    def get_category_by_name(self, name: str) -> Optional[Category]:
        """
        Получение категории по имени из MongoDB.
        
        Args:
            name: Имя категории
            
        Returns:
            Объект категории или None, если категория не найдена
        """
        categories = self.db.find_documents("categories", {"name": name}, limit=1)
        
        if categories:
            # Преобразуем _id в id
            categories[0]["id"] = categories[0].pop("_id")
            
            # Создаем объект категории
            return Category.from_dict(categories[0])
        
        return None
    
    def get_all_categories(self) -> List[Category]:
        """
        Получение всех категорий из MongoDB.
        
        Returns:
            Список категорий
        """
        categories_dict = self.db.find_documents("categories")
        
        categories = []
        for category_dict in categories_dict:
            # Преобразуем _id в id
            category_dict["id"] = category_dict.pop("_id")
            
            # Создаем объект категории
            categories.append(Category.from_dict(category_dict))
        
        return categories
    
    def get_categories_by_user(self, user_id: str) -> List[Category]:
        """
        Получение категорий, созданных пользователем, из MongoDB.
        
        Args:
            user_id: ID пользователя
            
        Returns:
            Список категорий
        """
        categories_dict = self.db.find_documents("categories", {"created_by": user_id})
        
        categories = []
        for category_dict in categories_dict:
            # Преобразуем _id в id
            category_dict["id"] = category_dict.pop("_id")
            
            # Создаем объект категории
            categories.append(Category.from_dict(category_dict))
        
        return categories
    
    # Методы для рабо
(Content truncated due to size limit. Use line ranges to read in chunks)