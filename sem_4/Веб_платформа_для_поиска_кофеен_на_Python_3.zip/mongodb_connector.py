"""
Модуль для интеграции с MongoDB.
"""
import os
import pymongo
from typing import Dict, List, Any, Optional, Tuple
from pymongo import MongoClient
from pymongo.collection import Collection
from pymongo.database import Database


class MongoDBConnector:
    """
    Класс для подключения к MongoDB и выполнения операций с базой данных.
    """
    
    def __init__(self, connection_string: str = None, db_name: str = "coffee_finder"):
        """
        Инициализация подключения к MongoDB.
        
        Args:
            connection_string: Строка подключения к MongoDB
            db_name: Имя базы данных
        """
        # Используем переменные окружения или значения по умолчанию
        self.connection_string = connection_string or os.environ.get(
            'MONGODB_CONNECTION_STRING', 
            'mongodb://localhost:27017/'
        )
        self.db_name = db_name
        self.client = None
        self.db = None
        
        # Подключаемся к базе данных
        self.connect()
    
    def connect(self) -> bool:
        """
        Подключение к MongoDB.
        
        Returns:
            True, если подключение успешно, иначе False
        """
        try:
            # Создаем клиент MongoDB
            self.client = MongoClient(self.connection_string)
            
            # Получаем базу данных
            self.db = self.client[self.db_name]
            
            # Проверяем подключение
            self.client.admin.command('ping')
            
            print(f"Успешное подключение к MongoDB: {self.db_name}")
            return True
        except Exception as e:
            print(f"Ошибка подключения к MongoDB: {str(e)}")
            self.client = None
            self.db = None
            return False
    
    def disconnect(self) -> None:
        """
        Отключение от MongoDB.
        """
        if self.client:
            self.client.close()
            self.client = None
            self.db = None
    
    def get_collection(self, collection_name: str) -> Optional[Collection]:
        """
        Получение коллекции из базы данных.
        
        Args:
            collection_name: Имя коллекции
            
        Returns:
            Объект коллекции или None, если подключение не установлено
        """
        if not self.db:
            if not self.connect():
                return None
        
        return self.db[collection_name]
    
    def create_document(self, collection_name: str, document: Dict[str, Any]) -> Optional[str]:
        """
        Создание документа в коллекции.
        
        Args:
            collection_name: Имя коллекции
            document: Документ для создания
            
        Returns:
            ID созданного документа или None в случае ошибки
        """
        collection = self.get_collection(collection_name)
        
        if not collection:
            return None
        
        try:
            result = collection.insert_one(document)
            return str(result.inserted_id)
        except Exception as e:
            print(f"Ошибка создания документа: {str(e)}")
            return None
    
    def read_document(self, collection_name: str, document_id: str) -> Optional[Dict[str, Any]]:
        """
        Чтение документа из коллекции.
        
        Args:
            collection_name: Имя коллекции
            document_id: ID документа
            
        Returns:
            Документ или None, если документ не найден или произошла ошибка
        """
        collection = self.get_collection(collection_name)
        
        if not collection:
            return None
        
        try:
            from bson.objectid import ObjectId
            document = collection.find_one({"_id": ObjectId(document_id)})
            
            if document:
                # Преобразуем ObjectId в строку для сериализации
                document["_id"] = str(document["_id"])
            
            return document
        except Exception as e:
            print(f"Ошибка чтения документа: {str(e)}")
            return None
    
    def update_document(self, collection_name: str, document_id: str, 
                        update_data: Dict[str, Any]) -> bool:
        """
        Обновление документа в коллекции.
        
        Args:
            collection_name: Имя коллекции
            document_id: ID документа
            update_data: Данные для обновления
            
        Returns:
            True, если обновление успешно, иначе False
        """
        collection = self.get_collection(collection_name)
        
        if not collection:
            return False
        
        try:
            from bson.objectid import ObjectId
            result = collection.update_one(
                {"_id": ObjectId(document_id)},
                {"$set": update_data}
            )
            
            return result.modified_count > 0
        except Exception as e:
            print(f"Ошибка обновления документа: {str(e)}")
            return False
    
    def delete_document(self, collection_name: str, document_id: str) -> bool:
        """
        Удаление документа из коллекции.
        
        Args:
            collection_name: Имя коллекции
            document_id: ID документа
            
        Returns:
            True, если удаление успешно, иначе False
        """
        collection = self.get_collection(collection_name)
        
        if not collection:
            return False
        
        try:
            from bson.objectid import ObjectId
            result = collection.delete_one({"_id": ObjectId(document_id)})
            
            return result.deleted_count > 0
        except Exception as e:
            print(f"Ошибка удаления документа: {str(e)}")
            return False
    
    def find_documents(self, collection_name: str, query: Dict[str, Any] = None, 
                       sort_by: List[Tuple[str, int]] = None, limit: int = 0) -> List[Dict[str, Any]]:
        """
        Поиск документов в коллекции.
        
        Args:
            collection_name: Имя коллекции
            query: Запрос для поиска
            sort_by: Параметры сортировки (список кортежей (поле, направление))
            limit: Максимальное количество результатов
            
        Returns:
            Список найденных документов
        """
        collection = self.get_collection(collection_name)
        
        if not collection:
            return []
        
        try:
            # Выполняем запрос
            cursor = collection.find(query or {})
            
            # Применяем сортировку
            if sort_by:
                cursor = cursor.sort(sort_by)
            
            # Применяем лимит
            if limit > 0:
                cursor = cursor.limit(limit)
            
            # Преобразуем ObjectId в строку для сериализации
            result = []
            for document in cursor:
                document["_id"] = str(document["_id"])
                result.append(document)
            
            return result
        except Exception as e:
            print(f"Ошибка поиска документов: {str(e)}")
            return []
    
    def count_documents(self, collection_name: str, query: Dict[str, Any] = None) -> int:
        """
        Подсчет количества документов в коллекции.
        
        Args:
            collection_name: Имя коллекции
            query: Запрос для поиска
            
        Returns:
            Количество документов
        """
        collection = self.get_collection(collection_name)
        
        if not collection:
            return 0
        
        try:
            return collection.count_documents(query or {})
        except Exception as e:
            print(f"Ошибка подсчета документов: {str(e)}")
            return 0
    
    def create_index(self, collection_name: str, keys: List[Tuple[str, int]], 
                     unique: bool = False) -> bool:
        """
        Создание индекса в коллекции.
        
        Args:
            collection_name: Имя коллекции
            keys: Ключи индекса (список кортежей (поле, направление))
            unique: Флаг уникальности индекса
            
        Returns:
            True, если индекс успешно создан, иначе False
        """
        collection = self.get_collection(collection_name)
        
        if not collection:
            return False
        
        try:
            collection.create_index(keys, unique=unique)
            return True
        except Exception as e:
            print(f"Ошибка создания индекса: {str(e)}")
            return False
    
    def aggregate(self, collection_name: str, pipeline: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Выполнение агрегации в коллекции.
        
        Args:
            collection_name: Имя коллекции
            pipeline: Конвейер агрегации
            
        Returns:
            Результат агрегации
        """
        collection = self.get_collection(collection_name)
        
        if not collection:
            return []
        
        try:
            # Выполняем агрегацию
            cursor = collection.aggregate(pipeline)
            
            # Преобразуем ObjectId в строку для сериализации
            result = []
            for document in cursor:
                if "_id" in document and hasattr(document["_id"], "__str__"):
                    document["_id"] = str(document["_id"])
                result.append(document)
            
            return result
        except Exception as e:
            print(f"Ошибка выполнения агрегации: {str(e)}")
            return []
