"""
Базовый веб-сервер без использования фреймворков.
Реализует WSGI-совместимый сервер с маршрутизацией запросов.
"""
import os
import sys
import mimetypes
import traceback
from typing import Dict, Any, List, Tuple, Callable, Optional
from wsgiref.simple_server import make_server

# Добавляем корневую директорию проекта в sys.path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from src.common.utils.http_utils import (
    parse_query_string, parse_request_body, json_response, 
    html_response, not_found_response, method_not_allowed_response,
    server_error_response
)


class Router:
    """
    Маршрутизатор HTTP-запросов.
    """
    def __init__(self):
        self.routes = {}
        self.static_dir = None
        self.templates_dir = None
    
    def add_route(self, path: str, handler: Callable, methods: List[str] = None):
        """
        Добавление маршрута.
        
        Args:
            path: Путь URL
            handler: Обработчик запроса
            methods: Список поддерживаемых HTTP-методов
        """
        if methods is None:
            methods = ['GET']
        
        self.routes[path] = {
            'handler': handler,
            'methods': methods
        }
    
    def set_static_dir(self, static_dir: str):
        """
        Установка директории для статических файлов.
        
        Args:
            static_dir: Путь к директории со статическими файлами
        """
        self.static_dir = static_dir
    
    def set_templates_dir(self, templates_dir: str):
        """
        Установка директории для шаблонов.
        
        Args:
            templates_dir: Путь к директории с шаблонами
        """
        self.templates_dir = templates_dir
    
    def serve_static_file(self, path: str) -> Optional[Tuple[str, List[Tuple[str, str]], List[bytes]]]:
        """
        Отдача статического файла.
        
        Args:
            path: Путь к файлу относительно static_dir
            
        Returns:
            Ответ WSGI или None, если файл не найден
        """
        if not self.static_dir:
            return None
        
        file_path = os.path.join(self.static_dir, path.lstrip('/'))
        
        if not os.path.exists(file_path) or not os.path.isfile(file_path):
            return None
        
        # Определяем MIME-тип файла
        content_type, _ = mimetypes.guess_type(file_path)
        if not content_type:
            content_type = 'application/octet-stream'
        
        # Читаем файл
        with open(file_path, 'rb') as f:
            file_content = f.read()
        
        # Формируем ответ
        headers = [
            ('Content-Type', content_type),
            ('Content-Length', str(len(file_content)))
        ]
        
        return '200 OK', headers, [file_content]
    
    def dispatch(self, environ: Dict[str, Any]) -> Tuple[str, List[Tuple[str, str]], List[bytes]]:
        """
        Диспетчеризация запроса.
        
        Args:
            environ: Окружение WSGI
            
        Returns:
            Ответ WSGI (статус, заголовки, тело)
        """
        path = environ['PATH_INFO']
        method = environ['REQUEST_METHOD']
        
        # Проверяем, не запрос ли это к статическому файлу
        if path.startswith('/static/'):
            static_response = self.serve_static_file(path[7:])  # Убираем '/static/' из пути
            if static_response:
                return static_response
        
        # Ищем обработчик для пути
        route = self.routes.get(path)
        
        if not route:
            return not_found_response()
        
        if method not in route['methods']:
            return method_not_allowed_response()
        
        try:
            # Подготавливаем параметры запроса
            query_params = parse_query_string(environ.get('QUERY_STRING', ''))
            body_params = parse_request_body(environ)
            
            # Вызываем обработчик
            return route['handler'](environ, query_params, body_params)
        except Exception as e:
            print(f"Error handling request: {e}")
            traceback.print_exc()
            return server_error_response()


class WebServer:
    """
    Веб-сервер на основе WSGI.
    """
    def __init__(self, host: str = 'localhost', port: int = 8000):
        self.host = host
        self.port = port
        self.router = Router()
    
    def set_static_dir(self, static_dir: str):
        """
        Установка директории для статических файлов.
        
        Args:
            static_dir: Путь к директории со статическими файлами
        """
        self.router.set_static_dir(static_dir)
    
    def set_templates_dir(self, templates_dir: str):
        """
        Установка директории для шаблонов.
        
        Args:
            templates_dir: Путь к директории с шаблонами
        """
        self.router.set_templates_dir(templates_dir)
    
    def add_route(self, path: str, handler: Callable, methods: List[str] = None):
        """
        Добавление маршрута.
        
        Args:
            path: Путь URL
            handler: Обработчик запроса
            methods: Список поддерживаемых HTTP-методов
        """
        self.router.add_route(path, handler, methods)
    
    def wsgi_app(self, environ: Dict[str, Any], start_response: Callable):
        """
        WSGI-приложение.
        
        Args:
            environ: Окружение WSGI
            start_response: Функция для начала ответа
            
        Returns:
            Итерируемый объект с телом ответа
        """
        status, headers, body = self.router.dispatch(environ)
        start_response(status, headers)
        return body
    
    def run(self):
        """
        Запуск веб-сервера.
        """
        print(f"Starting server on http://{self.host}:{self.port}")
        httpd = make_server(self.host, self.port, self.wsgi_app)
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("Server stopped")


def render_template(template_path: str, context: Dict[str, Any] = None) -> str:
    """
    Простой рендеринг шаблона.
    
    Args:
        template_path: Путь к файлу шаблона
        context: Контекст для рендеринга
        
    Returns:
        HTML-строка
    """
    if context is None:
        context = {}
    
    if not os.path.exists(template_path):
        return f"Template not found: {template_path}"
    
    with open(template_path, 'r', encoding='utf-8') as f:
        template = f.read()
    
    # Очень простая замена переменных в шаблоне
    # В реальном проекте нужно использовать более мощный шаблонизатор
    for key, value in context.items():
        template = template.replace(f"{{{{ {key} }}}}", str(value))
    
    return template
