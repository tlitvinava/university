"""
Сервис для работы с пользователями.
"""
import time
from typing import Dict, List, Any, Optional, Tuple

from src.business.models.user import User
from src.data.repositories.user_repository import UserRepository


class UserService:
    """
    Сервис для работы с пользователями.
    """
    def __init__(self, user_repository: UserRepository = None):
        """
        Инициализация сервиса.
        
        Args:
            user_repository: Репозиторий пользователей
        """
        self.user_repository = user_repository or UserRepository()
    
    def register_user(self, username: str, email: str, password: str) -> Tuple[bool, str, Optional[User]]:
        """
        Регистрация нового пользователя.
        
        Args:
            username: Имя пользователя
            email: Email
            password: Пароль
            
        Returns:
            Кортеж (успех, сообщение, пользователь)
        """
        # Валидация данных
        if not username or not email or not password:
            return False, "Все поля должны быть заполнены", None
        
        # Проверка, не существует ли уже пользователь с таким email или username
        if self.user_repository.get_user_by_email(email):
            return False, f"Пользователь с email {email} уже существует", None
        
        if self.user_repository.get_user_by_username(username):
            return False, f"Пользователь с именем {username} уже существует", None
        
        # Создаем пользователя
        password_hash = User.hash_password(password)
        user = User(
            username=username,
            email=email,
            password_hash=password_hash
        )
        
        created_user = self.user_repository.create_user(user)
        
        if created_user:
            return True, "Пользователь успешно зарегистрирован", created_user
        
        return False, "Ошибка при регистрации пользователя", None
    
    def authenticate_user(self, email: str, password: str) -> Tuple[bool, str, Optional[User]]:
        """
        Аутентификация пользователя.
        
        Args:
            email: Email
            password: Пароль
            
        Returns:
            Кортеж (успех, сообщение, пользователь)
        """
        # Валидация данных
        if not email or not password:
            return False, "Email и пароль должны быть заполнены", None
        
        # Аутентификация
        user = self.user_repository.get_user_by_email(email)
        
        if not user:
            return False, "Пользователь не найден", None
        
        if User.verify_password(user.password_hash, password):
            # Обновляем время последнего входа
            user.last_login = int(time.time())
            self.user_repository.update_user(user)
            return True, "Аутентификация успешна", user
        
        return False, "Неверный пароль", None
    
    def get_user_profile(self, user_id: int) -> Optional[User]:
        """
        Получение профиля пользователя.
        
        Args:
            user_id: ID пользователя
            
        Returns:
            Объект пользователя или None, если пользователь не найден
        """
        return self.user_repository.get_user_by_id(user_id)
    
    def update_user_profile(self, user_id: int, username: str = None, email: str = None) -> Tuple[bool, str, Optional[User]]:
        """
        Обновление профиля пользователя.
        
        Args:
            user_id: ID пользователя
            username: Новое имя пользователя
            email: Новый email
            
        Returns:
            Кортеж (успех, сообщение, пользователь)
        """
        user = self.user_repository.get_user_by_id(user_id)
        
        if not user:
            return False, "Пользователь не найден", None
        
        # Обновляем данные
        if username is not None and username != user.username:
            # Проверяем, не занято ли имя пользователя
            if self.user_repository.get_user_by_username(username):
                return False, f"Пользователь с именем {username} уже существует", None
            
            user.username = username
        
        if email is not None and email != user.email:
            # Проверяем, не занят ли email
            if self.user_repository.get_user_by_email(email):
                return False, f"Пользователь с email {email} уже существует", None
            
            user.email = email
        
        # Сохраняем изменения
        updated_user = self.user_repository.update_user(user)
        
        if updated_user:
            return True, "Профиль успешно обновлен", updated_user
        
        return False, "Ошибка при обновлении профиля", None
    
    def change_password(self, user_id: int, old_password: str, new_password: str) -> Tuple[bool, str]:
        """
        Изменение пароля пользователя.
        
        Args:
            user_id: ID пользователя
            old_password: Старый пароль
            new_password: Новый пароль
            
        Returns:
            Кортеж (успех, сообщение)
        """
        user = self.user_repository.get_user_by_id(user_id)
        
        if not user:
            return False, "Пользователь не найден"
        
        # Проверяем старый пароль
        if not User.verify_password(user.password_hash, old_password):
            return False, "Неверный старый пароль"
        
        # Устанавливаем новый пароль
        user.password_hash = User.hash_password(new_password)
        
        # Сохраняем изменения
        if self.user_repository.update_user(user):
            return True, "Пароль успешно изменен"
        
        return False, "Ошибка при изменении пароля"
    
    def get_friends(self, user_id: int) -> List[User]:
        """
        Получение друзей пользователя.
        
        Args:
            user_id: ID пользователя
            
        Returns:
            Список друзей
        """
        return self.user_repository.get_friends(user_id)
    
    def add_friend(self, user_id: int, friend_id: int) -> Tuple[bool, str]:
        """
        Добавление друга.
        
        Args:
            user_id: ID пользователя
            friend_id: ID друга
            
        Returns:
            Кортеж (успех, сообщение)
        """
        # Проверяем, существуют ли пользователи
        user = self.user_repository.get_user_by_id(user_id)
        friend = self.user_repository.get_user_by_id(friend_id)
        
        if not user:
            return False, "Пользователь не найден"
        
        if not friend:
            return False, "Друг не найден"
        
        # Проверяем, не пытается ли пользователь добавить сам себя
        if user_id == friend_id:
            return False, "Нельзя добавить себя в друзья"
        
        # Проверяем, не является ли пользователь уже другом
        if friend_id in user.friends:
            return False, "Пользователь уже в списке друзей"
        
        # Добавляем друга
        if self.user_repository.add_friend(user_id, friend_id):
            return True, "Друг успешно добавлен"
        
        return False, "Ошибка при добавлении друга"
    
    def remove_friend(self, user_id: int, friend_id: int) -> Tuple[bool, str]:
        """
        Удаление друга.
        
        Args:
            user_id: ID пользователя
            friend_id: ID друга
            
        Returns:
            Кортеж (успех, сообщение)
        """
        # Проверяем, существует ли пользователь
        user = self.user_repository.get_user_by_id(user_id)
        
        if not user:
            return False, "Пользователь не найден"
        
        # Проверяем, является ли пользователь другом
        if friend_id not in user.friends:
            return False, "Пользователь не в списке друзей"
        
        # Удаляем друга
        if self.user_repository.remove_friend(user_id, friend_id):
            return True, "Друг успешно удален"
        
        return False, "Ошибка при удалении друга"
    
    def update_location(self, user_id: int, latitude: float, longitude: float) -> Tuple[bool, str]:
        """
        Обновление местоположения пользователя.
        
        Args:
            user_id: ID пользователя
            latitude: Широта
            longitude: Долгота
            
        Returns:
            Кортеж (успех, сообщение)
        """
        user = self.user_repository.get_user_by_id(user_id)
        
        if not user:
            return False, "Пользователь не найден"
        
        # Обновляем местоположение
        user.update_location(latitude, longitude)
        
        # Сохраняем изменения
        if self.user_repository.update_user(user):
            return True, "Местоположение успешно обновлено"
        
        return False, "Ошибка при обновлении местоположения"
