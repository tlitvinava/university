"""
Модуль для работы с файлами и директориями.
"""
import os
import json
from typing import Any, Dict, List, Optional


def ensure_directory_exists(directory_path: str) -> None:
    """
    Убедиться, что директория существует, создать при необходимости.
    
    Args:
        directory_path: Путь к директории
    """
    if not os.path.exists(directory_path):
        os.makedirs(directory_path)


def read_json_file(file_path: str) -> Dict[str, Any]:
    """
    Чтение JSON-файла.
    
    Args:
        file_path: Путь к файлу
        
    Returns:
        Данные из JSON-файла или пустой словарь, если файл не существует
    """
    if not os.path.exists(file_path):
        return {}
    
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except (json.JSONDecodeError, IOError) as e:
        print(f"Error reading JSON file {file_path}: {e}")
        return {}


def write_json_file(file_path: str, data: Dict[str, Any]) -> bool:
    """
    Запись данных в JSON-файл.
    
    Args:
        file_path: Путь к файлу
        data: Данные для записи
        
    Returns:
        True, если запись успешна, иначе False
    """
    directory = os.path.dirname(file_path)
    ensure_directory_exists(directory)
    
    try:
        with open(file_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        return True
    except IOError as e:
        print(f"Error writing JSON file {file_path}: {e}")
        return False


def append_to_json_list(file_path: str, item: Dict[str, Any], id_field: str = 'id') -> Optional[Dict[str, Any]]:
    """
    Добавление элемента в JSON-список.
    
    Args:
        file_path: Путь к файлу
        item: Элемент для добавления
        id_field: Поле идентификатора для проверки уникальности
        
    Returns:
        Добавленный элемент с присвоенным ID или None в случае ошибки
    """
    data = read_json_file(file_path)
    
    if not data:
        data = {'items': []}
    
    items = data.get('items', [])
    
    # Генерируем новый ID, если он не указан
    if id_field in item and item[id_field] is not None:
        # Проверяем уникальность ID
        if any(existing[id_field] == item[id_field] for existing in items if id_field in existing):
            print(f"Item with {id_field}={item[id_field]} already exists")
            return None
    else:
        # Генерируем новый ID
        max_id = 0
        for existing in items:
            if id_field in existing and isinstance(existing[id_field], int) and existing[id_field] > max_id:
                max_id = existing[id_field]
        item[id_field] = max_id + 1
    
    items.append(item)
    data['items'] = items
    
    if write_json_file(file_path, data):
        return item
    
    return None


def update_json_item(file_path: str, item_id: int, updated_item: Dict[str, Any], id_field: str = 'id') -> Optional[Dict[str, Any]]:
    """
    Обновление элемента в JSON-списке.
    
    Args:
        file_path: Путь к файлу
        item_id: ID элемента для обновления
        updated_item: Обновленный элемент
        id_field: Поле идентификатора
        
    Returns:
        Обновленный элемент или None, если элемент не найден или произошла ошибка
    """
    data = read_json_file(file_path)
    
    if not data or 'items' not in data:
        return None
    
    items = data['items']
    
    for i, item in enumerate(items):
        if id_field in item and item[id_field] == item_id:
            # Сохраняем ID
            updated_item[id_field] = item_id
            items[i] = updated_item
            
            if write_json_file(file_path, data):
                return updated_item
            
            return None
    
    return None


def delete_json_item(file_path: str, item_id: int, id_field: str = 'id') -> bool:
    """
    Удаление элемента из JSON-списка.
    
    Args:
        file_path: Путь к файлу
        item_id: ID элемента для удаления
        id_field: Поле идентификатора
        
    Returns:
        True, если элемент успешно удален, иначе False
    """
    data = read_json_file(file_path)
    
    if not data or 'items' not in data:
        return False
    
    items = data['items']
    original_length = len(items)
    
    data['items'] = [item for item in items if id_field not in item or item[id_field] != item_id]
    
    if len(data['items']) == original_length:
        # Элемент не найден
        return False
    
    return write_json_file(file_path, data)


def get_json_item(file_path: str, item_id: int, id_field: str = 'id') -> Optional[Dict[str, Any]]:
    """
    Получение элемента из JSON-списка по ID.
    
    Args:
        file_path: Путь к файлу
        item_id: ID элемента
        id_field: Поле идентификатора
        
    Returns:
        Элемент или None, если элемент не найден
    """
    data = read_json_file(file_path)
    
    if not data or 'items' not in data:
        return None
    
    for item in data['items']:
        if id_field in item and item[id_field] == item_id:
            return item
    
    return None


def get_all_json_items(file_path: str) -> List[Dict[str, Any]]:
    """
    Получение всех элементов из JSON-списка.
    
    Args:
        file_path: Путь к файлу
        
    Returns:
        Список элементов или пустой список, если файл не существует
    """
    data = read_json_file(file_path)
    
    if not data or 'items' not in data:
        return []
    
    return data['items']
