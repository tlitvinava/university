"""
Обработчики HTTP-запросов для работы с пользователями.
"""
import json
import os
from typing import Dict, Any, List, Tuple, Callable

from src.business.services.user_service import UserService
from src.common.utils.http_utils import (
    json_response, html_response, redirect_response,
    not_found_response, method_not_allowed_response
)


class UserHandlers:
    """
    Обработчики HTTP-запросов для работы с пользователями.
    """
    def __init__(self, user_service: UserService = None):
        """
        Инициализация обработчиков.
        
        Args:
            user_service: Сервис для работы с пользователями
        """
        self.user_service = user_service or UserService()
        
        # Путь к директории с шаблонами
        base_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        self.templates_dir = os.path.join(base_dir, 'presentation', 'templates')
    
    def register_handler(self, environ: Dict[str, Any], query_params: Dict[str, str], body_params: Dict[str, Any]) -> Tuple[str, List[Tuple[str, str]], List[bytes]]:
        """
        Обработчик регистрации пользователя.
        
        Args:
            environ: Окружение WSGI
            query_params: Параметры запроса
            body_params: Параметры тела запроса
            
        Returns:
            Ответ WSGI (статус, заголовки, тело)
        """
        method = environ['REQUEST_METHOD']
        
        if method == 'GET':
            # Отображаем форму регистрации
            template_path = os.path.join(self.templates_dir, 'register.html')
            
            if os.path.exists(template_path):
                with open(template_path, 'r', encoding='utf-8') as f:
                    html = f.read()
                return html_response(html)
            else:
                # Если шаблон не найден, возвращаем простую HTML-форму
                html = """
                <!DOCTYPE html>
                <html>
                <head>
                    <title>Регистрация</title>
                    <meta charset="utf-8">
                    <meta name="viewport" content="width=device-width, initial-scale=1">
                    <style>
                        body {
                            font-family: Arial, sans-serif;
                            margin: 0;
                            padding: 20px;
                            background-color: #f5f5f5;
                        }
                        .container {
                            max-width: 500px;
                            margin: 0 auto;
                            background-color: white;
                            padding: 20px;
                            border-radius: 5px;
                            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
                        }
                        h1 {
                            text-align: center;
                            color: #333;
                        }
                        .form-group {
                            margin-bottom: 15px;
                        }
                        label {
                            display: block;
                            margin-bottom: 5px;
                            font-weight: bold;
                        }
                        input[type="text"],
                        input[type="email"],
                        input[type="password"] {
                            width: 100%;
                            padding: 8px;
                            border: 1px solid #ddd;
                            border-radius: 4px;
                            box-sizing: border-box;
                        }
                        button {
                            background-color: #4CAF50;
                            color: white;
                            padding: 10px 15px;
                            border: none;
                            border-radius: 4px;
                            cursor: pointer;
                            font-size: 16px;
                        }
                        button:hover {
                            background-color: #45a049;
                        }
                        .error {
                            color: red;
                            margin-bottom: 15px;
                        }
                        .success {
                            color: green;
                            margin-bottom: 15px;
                        }
                    </style>
                </head>
                <body>
                    <div class="container">
                        <h1>Регистрация</h1>
                        <div id="message"></div>
                        <form id="registerForm" method="post" action="/api/users/register">
                            <div class="form-group">
                                <label for="username">Имя пользователя:</label>
                                <input type="text" id="username" name="username" required>
                            </div>
                            <div class="form-group">
                                <label for="email">Email:</label>
                                <input type="email" id="email" name="email" required>
                            </div>
                            <div class="form-group">
                                <label for="password">Пароль:</label>
                                <input type="password" id="password" name="password" required>
                            </div>
                            <div class="form-group">
                                <label for="confirm_password">Подтверждение пароля:</label>
                                <input type="password" id="confirm_password" name="confirm_password" required>
                            </div>
                            <button type="submit">Зарегистрироваться</button>
                        </form>
                        <p>Уже есть аккаунт? <a href="/login">Войти</a></p>
                    </div>
                    
                    <script>
                        document.getElementById('registerForm').addEventListener('submit', function(e) {
                            e.preventDefault();
                            
                            const username = document.getElementById('username').value;
                            const email = document.getElementById('email').value;
                            const password = document.getElementById('password').value;
                            const confirmPassword = document.getElementById('confirm_password').value;
                            
                            // Проверка паролей
                            if (password !== confirmPassword) {
                                document.getElementById('message').innerHTML = '<div class="error">Пароли не совпадают</div>';
                                return;
                            }
                            
                            // Отправка данных на сервер
                            fetch('/api/users/register', {
                                method: 'POST',
                                headers: {
                                    'Content-Type': 'application/json'
                                },
                                body: JSON.stringify({
                                    username: username,
                                    email: email,
                                    password: password
                                })
                            })
                            .then(response => response.json())
                            .then(data => {
                                if (data.success) {
                                    document.getElementById('message').innerHTML = '<div class="success">' + data.message + '</div>';
                                    // Перенаправление на страницу входа
                                    setTimeout(() => {
                                        window.location.href = '/login';
                                    }, 2000);
                                } else {
                                    document.getElementById('message').innerHTML = '<div class="error">' + data.message + '</div>';
                                }
                            })
                            .catch(error => {
                                document.getElementById('message').innerHTML = '<div class="error">Произошла ошибка при регистрации</div>';
                                console.error('Error:', error);
                            });
                        });
                    </script>
                </body>
                </html>
                """
                return html_response(html)
        
        elif method == 'POST':
            # Обрабатываем данные формы регистрации
            username = body_params.get('username', '')
            email = body_params.get('email', '')
            password = body_params.get('password', '')
            
            success, message, user = self.user_service.register_user(username, email, password)
            
            # Возвращаем JSON-ответ
            response_data = {
                'success': success,
                'message': message
            }
            
            if user:
                response_data['user'] = {
                    'id': user.id,
                    'username': user.username,
                    'email': user.email
                }
            
            return json_response(response_data)
        
        return method_not_allowed_response()
    
    def login_handler(self, environ: Dict[str, Any], query_params: Dict[str, str], body_params: Dict[str, Any]) -> Tuple[str, List[Tuple[str, str]], List[bytes]]:
        """
        Обработчик входа пользователя.
        
        Args:
            environ: Окружение WSGI
            query_params: Параметры запроса
            body_params: Параметры тела запроса
            
        Returns:
            Ответ WSGI (статус, заголовки, тело)
        """
        method = environ['REQUEST_METHOD']
        
        if method == 'GET':
            # Отображаем форму входа
            template_path = os.path.join(self.templates_dir, 'login.html')
            
            if os.path.exists(template_path):
                with open(template_path, 'r', encoding='utf-8') as f:
                    html = f.read()
                return html_response(html)
            else:
                # Если шаблон не найден, возвращаем простую HTML-форму
                html = """
                <!DOCTYPE html>
                <html>
                <head>
                    <title>Вход</title>
                    <meta charset="utf-8">
                    <meta name="viewport" content="width=device-width, initial-scale=1">
                    <style>
                        body {
                            font-family: Arial, sans-serif;
                            margin: 0;
                            padding: 20px;
                            background-color: #f5f5f5;
                        }
                        .container {
                            max-width: 500px;
                            margin: 0 auto;
                            background-color: white;
                            padding: 20px;
                            border-radius: 5px;
                            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
                        }
                        h1 {
                            text-align: center;
                            color: #333;
                        }
                        .form-group {
                            margin-bottom: 15px;
                        }
                        label {
                            display: block;
                            margin-bottom: 5px;
                            font-weight: bold;
                        }
                        input[type="email"],
                        input[type="password"] {
                            width: 100%;
                            padding: 8px;
                            border: 1px solid #ddd;
                            border-radius: 4px;
                            box-sizing: border-box;
                        }
                        button {
                            background-color: #4CAF50;
                            color: white;
                            padding: 10px 15px;
                            border: none;
                            border-radius: 4px;
                            cursor: pointer;
                            font-size: 16px;
                        }
                        button:hover {
                            background-color: #45a049;
                        }
                        .error {
                            color: red;
                            margin-bottom: 15px;
                        }
                        .success {
                            color: green;
                            margin-bottom: 15px;
                        }
                    </style>
                </head>
                <body>
                    <div class="container">
                        <h1>Вход</h1>
                        <div id="message"></div>
                        <form id="loginForm" method="post" action="/api/users/login">
                            <div class="form-group">
                                <label for="email">Email:</label>
                                <input type="email" id="email" name="email" required>
                            </div>
                            <div class="form-group">
                                <label for="password">Пароль:</label>
                                <input type="password" id="password" name="password" required>
                            </div>
                            <button type="submit">Войти</button>
                        </form>
                        <p>Нет аккаунта? <a href="/register">Зарегистрироваться</a></p>
                    </div>
                    
                    <script>
                        document.getElementById('loginForm').addEventListener('submit', function(e) {
                            e.preventDefault();
                            
                            const email = document.getElementById('email').value;
                            const password = document.getElementById('password').value;
                            
                            // Отправка данных на сервер
                            fetch('/api/users/login', {
                                method: 'POST',
                                headers: {
                                    'Content-Type': 'application/json'
                                },
                                body: JSON.stringify({
                                    email: email,
                                    password: password
                                })
                            })
                            .then(response => response.json())
                            .then(data => {
                                if (data.success) {
                                    document.getElementById('message').innerHTML = '<div class="success">' + data.message + '</div>';
                                    // Сохраняем данные пользователя в localStorage
                                    localStorage.setItem('user', JSON.stringify(data.user));
                                    // Перенаправление на главную страницу
                                    setTimeout(() => {
                                        window.location.href = '/';
                                    }, 1000);
                                } else {
                                    document.getElementById('message').innerHTML = '<div class="error">' +
(Content truncated due to size limit. Use line ranges to read in chunks)