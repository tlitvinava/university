"""
Репозиторий для работы с пользователями.
"""
from typing import Dict, List, Any, Optional
import os
import json

from src.business.models.user import User
from src.common.utils.file_utils import (
    read_json_file, write_json_file, append_to_json_list,
    update_json_item, delete_json_item, get_json_item, get_all_json_items
)


class UserRepository:
    """
    Репозиторий для работы с пользователями.
    """
    def __init__(self, data_dir: str = None):
        """
        Инициализация репозитория.
        
        Args:
            data_dir: Директория для хранения данных
        """
        if data_dir is None:
            # Используем директорию по умолчанию
            base_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
            data_dir = os.path.join(base_dir, 'data', 'local')
        
        self.data_dir = data_dir
        self.users_file = os.path.join(data_dir, 'users.json')
        
        # Создаем директорию, если она не существует
        os.makedirs(data_dir, exist_ok=True)
        
        # Инициализируем файл пользователей, если он не существует
        if not os.path.exists(self.users_file):
            write_json_file(self.users_file, {'items': []})
    
    def create_user(self, user: User) -> Optional[User]:
        """
        Создание нового пользователя.
        
        Args:
            user: Объект пользователя
            
        Returns:
            Созданный пользователь или None в случае ошибки
        """
        # Проверяем, не существует ли уже пользователь с таким email или username
        existing_users = self.get_all_users()
        
        for existing_user in existing_users:
            if existing_user.email == user.email:
                print(f"User with email {user.email} already exists")
                return None
            
            if existing_user.username == user.username:
                print(f"User with username {user.username} already exists")
                return None
        
        # Добавляем пользователя
        user_dict = user.to_dict()
        result = append_to_json_list(self.users_file, user_dict)
        
        if result:
            return User.from_dict(result)
        
        return None
    
    def update_user(self, user: User) -> Optional[User]:
        """
        Обновление пользователя.
        
        Args:
            user: Объект пользователя
            
        Returns:
            Обновленный пользователь или None в случае ошибки
        """
        if user.id is None:
            return None
        
        user_dict = user.to_dict()
        result = update_json_item(self.users_file, user.id, user_dict)
        
        if result:
            return User.from_dict(result)
        
        return None
    
    def delete_user(self, user_id: int) -> bool:
        """
        Удаление пользователя.
        
        Args:
            user_id: ID пользователя
            
        Returns:
            True, если пользователь успешно удален, иначе False
        """
        return delete_json_item(self.users_file, user_id)
    
    def get_user_by_id(self, user_id: int) -> Optional[User]:
        """
        Получение пользователя по ID.
        
        Args:
            user_id: ID пользователя
            
        Returns:
            Объект пользователя или None, если пользователь не найден
        """
        user_dict = get_json_item(self.users_file, user_id)
        
        if user_dict:
            return User.from_dict(user_dict)
        
        return None
    
    def get_user_by_email(self, email: str) -> Optional[User]:
        """
        Получение пользователя по email.
        
        Args:
            email: Email пользователя
            
        Returns:
            Объект пользователя или None, если пользователь не найден
        """
        users = get_all_json_items(self.users_file)
        
        for user_dict in users:
            if user_dict.get('email') == email:
                return User.from_dict(user_dict)
        
        return None
    
    def get_user_by_username(self, username: str) -> Optional[User]:
        """
        Получение пользователя по имени пользователя.
        
        Args:
            username: Имя пользователя
            
        Returns:
            Объект пользователя или None, если пользователь не найден
        """
        users = get_all_json_items(self.users_file)
        
        for user_dict in users:
            if user_dict.get('username') == username:
                return User.from_dict(user_dict)
        
        return None
    
    def get_all_users(self) -> List[User]:
        """
        Получение всех пользователей.
        
        Returns:
            Список пользователей
        """
        users = get_all_json_items(self.users_file)
        return [User.from_dict(user_dict) for user_dict in users]
    
    def get_friends(self, user_id: int) -> List[User]:
        """
        Получение друзей пользователя.
        
        Args:
            user_id: ID пользователя
            
        Returns:
            Список друзей
        """
        user = self.get_user_by_id(user_id)
        
        if not user:
            return []
        
        friends = []
        for friend_id in user.friends:
            friend = self.get_user_by_id(friend_id)
            if friend:
                friends.append(friend)
        
        return friends
    
    def add_friend(self, user_id: int, friend_id: int) -> bool:
        """
        Добавление друга.
        
        Args:
            user_id: ID пользователя
            friend_id: ID друга
            
        Returns:
            True, если друг успешно добавлен, иначе False
        """
        user = self.get_user_by_id(user_id)
        friend = self.get_user_by_id(friend_id)
        
        if not user or not friend:
            return False
        
        if user.add_friend(friend_id):
            return self.update_user(user) is not None
        
        return False
    
    def remove_friend(self, user_id: int, friend_id: int) -> bool:
        """
        Удаление друга.
        
        Args:
            user_id: ID пользователя
            friend_id: ID друга
            
        Returns:
            True, если друг успешно удален, иначе False
        """
        user = self.get_user_by_id(user_id)
        
        if not user:
            return False
        
        if user.remove_friend(friend_id):
            return self.update_user(user) is not None
        
        return False
    
    def authenticate_user(self, email: str, password: str) -> Optional[User]:
        """
        Аутентификация пользователя.
        
        Args:
            email: Email пользователя
            password: Пароль
            
        Returns:
            Объект пользователя или None, если аутентификация не удалась
        """
        user = self.get_user_by_email(email)
        
        if not user:
            return None
        
        if User.verify_password(user.password_hash, password):
            # Обновляем время последнего входа
            user.last_login = int(time.time())
            self.update_user(user)
            return user
        
        return None
