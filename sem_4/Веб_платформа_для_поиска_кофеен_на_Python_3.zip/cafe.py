"""
Модель кофейни.
"""
from typing import Dict, List, Any, Optional
import time


class Cafe:
    """
    Класс, представляющий кофейню.
    """
    def __init__(
        self,
        id: Optional[int] = None,
        name: str = "",
        address: str = "",
        coordinates: Dict[str, float] = None,
        description: str = "",
        categories: List[int] = None,
        added_by: Optional[int] = None,
        visit_count: int = 0,
        external_id: str = "",
        rating: float = 0.0,
        features: Dict[str, Any] = None
    ):
        """
        Инициализация кофейни.
        
        Args:
            id: Уникальный идентификатор кофейни
            name: Название кофейни
            address: Адрес кофейни
            coordinates: Координаты (широта, долгота)
            description: Описание кофейни
            categories: Список ID категорий
            added_by: ID пользователя, добавившего кофейню
            visit_count: Количество посещений
            external_id: Внешний идентификатор (например, из API Яндекс.Карт)
            rating: Рейтинг кофейни
            features: Особенности кофейни (цена, наличие розеток, Wi-Fi и т.д.)
        """
        self.id = id
        self.name = name
        self.address = address
        self.coordinates = coordinates or {"latitude": 0.0, "longitude": 0.0}
        self.description = description
        self.categories = categories or []
        self.added_by = added_by
        self.visit_count = visit_count
        self.external_id = external_id
        self.rating = rating
        self.features = features or {}
        self.created_at = int(time.time())
        self.updated_at = int(time.time())
    
    def to_dict(self) -> Dict[str, Any]:
        """
        Преобразование кофейни в словарь.
        
        Returns:
            Словарь с данными кофейни
        """
        return {
            "id": self.id,
            "name": self.name,
            "address": self.address,
            "coordinates": self.coordinates,
            "description": self.description,
            "categories": self.categories,
            "added_by": self.added_by,
            "visit_count": self.visit_count,
            "external_id": self.external_id,
            "rating": self.rating,
            "features": self.features,
            "created_at": self.created_at,
            "updated_at": self.updated_at
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Cafe':
        """
        Создание кофейни из словаря.
        
        Args:
            data: Словарь с данными кофейни
            
        Returns:
            Объект кофейни
        """
        cafe = cls(
            id=data.get("id"),
            name=data.get("name", ""),
            address=data.get("address", ""),
            coordinates=data.get("coordinates", {"latitude": 0.0, "longitude": 0.0}),
            description=data.get("description", ""),
            categories=data.get("categories", []),
            added_by=data.get("added_by"),
            visit_count=data.get("visit_count", 0),
            external_id=data.get("external_id", ""),
            rating=data.get("rating", 0.0),
            features=data.get("features", {})
        )
        cafe.created_at = data.get("created_at", int(time.time()))
        cafe.updated_at = data.get("updated_at", int(time.time()))
        return cafe
    
    def increment_visit_count(self) -> None:
        """
        Увеличение счетчика посещений.
        """
        self.visit_count += 1
        self.updated_at = int(time.time())
    
    def update_rating(self, new_rating: float) -> None:
        """
        Обновление рейтинга кофейни.
        
        Args:
            new_rating: Новый рейтинг
        """
        self.rating = new_rating
        self.updated_at = int(time.time())
    
    def add_category(self, category_id: int) -> bool:
        """
        Добавление категории.
        
        Args:
            category_id: ID категории
            
        Returns:
            True, если категория успешно добавлена, иначе False
        """
        if category_id not in self.categories:
            self.categories.append(category_id)
            self.updated_at = int(time.time())
            return True
        
        return False
    
    def remove_category(self, category_id: int) -> bool:
        """
        Удаление категории.
        
        Args:
            category_id: ID категории
            
        Returns:
            True, если категория успешно удалена, иначе False
        """
        if category_id in self.categories:
            self.categories.remove(category_id)
            self.updated_at = int(time.time())
            return True
        
        return False
    
    def update_feature(self, feature_name: str, feature_value: Any) -> None:
        """
        Обновление особенности кофейни.
        
        Args:
            feature_name: Название особенности
            feature_value: Значение особенности
        """
        self.features[feature_name] = feature_value
        self.updated_at = int(time.time())
    
    def remove_feature(self, feature_name: str) -> bool:
        """
        Удаление особенности кофейни.
        
        Args:
            feature_name: Название особенности
            
        Returns:
            True, если особенность успешно удалена, иначе False
        """
        if feature_name in self.features:
            del self.features[feature_name]
            self.updated_at = int(time.time())
            return True
        
        return False


class Category:
    """
    Класс, представляющий категорию кофейни.
    """
    def __init__(
        self,
        id: Optional[int] = None,
        name: str = "",
        description: str = "",
        created_by: Optional[int] = None
    ):
        """
        Инициализация категории.
        
        Args:
            id: Уникальный идентификатор категории
            name: Название категории
            description: Описание категории
            created_by: ID пользователя, создавшего категорию
        """
        self.id = id
        self.name = name
        self.description = description
        self.created_by = created_by
        self.created_at = int(time.time())
    
    def to_dict(self) -> Dict[str, Any]:
        """
        Преобразование категории в словарь.
        
        Returns:
            Словарь с данными категории
        """
        return {
            "id": self.id,
            "name": self.name,
            "description": self.description,
            "created_by": self.created_by,
            "created_at": self.created_at
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Category':
        """
        Создание категории из словаря.
        
        Args:
            data: Словарь с данными категории
            
        Returns:
            Объект категории
        """
        category = cls(
            id=data.get("id"),
            name=data.get("name", ""),
            description=data.get("description", ""),
            created_by=data.get("created_by")
        )
        category.created_at = data.get("created_at", int(time.time()))
        return category


class Visit:
    """
    Класс, представляющий посещение кофейни.
    """
    def __init__(
        self,
        id: Optional[int] = None,
        user_id: Optional[int] = None,
        cafe_id: Optional[int] = None,
        timestamp: Optional[int] = None,
        duration: int = 0,
        rating: Optional[float] = None
    ):
        """
        Инициализация посещения.
        
        Args:
            id: Уникальный идентификатор посещения
            user_id: ID пользователя
            cafe_id: ID кофейни
            timestamp: Время посещения
            duration: Продолжительность посещения в минутах
            rating: Оценка кофейни
        """
        self.id = id
        self.user_id = user_id
        self.cafe_id = cafe_id
        self.timestamp = timestamp or int(time.time())
        self.duration = duration
        self.rating = rating
    
    def to_dict(self) -> Dict[str, Any]:
        """
        Преобразование посещения в словарь.
        
        Returns:
            Словарь с данными посещения
        """
        return {
            "id": self.id,
            "user_id": self.user_id,
            "cafe_id": self.cafe_id,
            "timestamp": self.timestamp,
            "duration": self.duration,
            "rating": self.rating
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Visit':
        """
        Создание посещения из словаря.
        
        Args:
            data: Словарь с данными посещения
            
        Returns:
            Объект посещения
        """
        return cls(
            id=data.get("id"),
            user_id=data.get("user_id"),
            cafe_id=data.get("cafe_id"),
            timestamp=data.get("timestamp", int(time.time())),
            duration=data.get("duration", 0),
            rating=data.get("rating")
        )
    
    def set_rating(self, rating: float) -> None:
        """
        Установка оценки.
        
        Args:
            rating: Оценка кофейни
        """
        self.rating = rating
