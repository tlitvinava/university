"""
Модуль для отслеживания местоположения пользователя и генерации уведомлений.
"""
import time
import math
from typing import Dict, List, Any, Optional, Tuple

from src.business.models.user import User
from src.business.models.cafe import Cafe, Visit
from src.data.repositories.user_repository import UserRepository
from src.data.repositories.cafe_repository import CafeRepository


class LocationTracker:
    """
    Класс для отслеживания местоположения пользователя.
    """
    def __init__(self, user_repository: UserRepository = None, cafe_repository: CafeRepository = None):
        """
        Инициализация трекера местоположения.
        
        Args:
            user_repository: Репозиторий пользователей
            cafe_repository: Репозиторий кофеен
        """
        self.user_repository = user_repository or UserRepository()
        self.cafe_repository = cafe_repository or CafeRepository()
        self.location_history = {}  # Словарь для хранения истории местоположений пользователей
    
    def update_user_location(self, user_id: int, latitude: float, longitude: float) -> Tuple[bool, str]:
        """
        Обновление местоположения пользователя.
        
        Args:
            user_id: ID пользователя
            latitude: Широта
            longitude: Долгота
            
        Returns:
            Кортеж (успех, сообщение)
        """
        # Получаем пользователя
        user = self.user_repository.get_user_by_id(user_id)
        
        if not user:
            return False, "Пользователь не найден"
        
        # Обновляем местоположение
        user.update_location(latitude, longitude)
        
        # Сохраняем изменения
        if self.user_repository.update_user(user):
            # Обновляем историю местоположений
            if user_id not in self.location_history:
                self.location_history[user_id] = []
            
            self.location_history[user_id].append({
                "latitude": latitude,
                "longitude": longitude,
                "timestamp": int(time.time())
            })
            
            return True, "Местоположение успешно обновлено"
        
        return False, "Ошибка при обновлении местоположения"
    
    def calculate_distance(self, lat1: float, lon1: float, lat2: float, lon2: float) -> float:
        """
        Расчет расстояния между двумя точками по координатам (формула гаверсинуса).
        
        Args:
            lat1: Широта первой точки
            lon1: Долгота первой точки
            lat2: Широта второй точки
            lon2: Долгота второй точки
            
        Returns:
            Расстояние в километрах
        """
        # Радиус Земли в километрах
        R = 6371.0
        
        # Перевод градусов в радианы
        lat1_rad = math.radians(lat1)
        lon1_rad = math.radians(lon1)
        lat2_rad = math.radians(lat2)
        lon2_rad = math.radians(lon2)
        
        # Разница координат
        dlon = lon2_rad - lon1_rad
        dlat = lat2_rad - lat1_rad
        
        # Формула гаверсинуса
        a = math.sin(dlat / 2)**2 + math.cos(lat1_rad) * math.cos(lat2_rad) * math.sin(dlon / 2)**2
        c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
        
        # Расстояние в километрах
        distance = R * c
        
        return distance
    
    def check_nearby_cafes(self, user_id: int, radius: float = 0.2) -> List[Cafe]:
        """
        Проверка наличия кофеен рядом с пользователем.
        
        Args:
            user_id: ID пользователя
            radius: Радиус поиска в километрах (по умолчанию 200 метров)
            
        Returns:
            Список ближайших кофеен
        """
        # Получаем пользователя
        user = self.user_repository.get_user_by_id(user_id)
        
        if not user:
            return []
        
        # Получаем координаты пользователя
        user_lat = user.location.get("latitude", 0)
        user_lon = user.location.get("longitude", 0)
        
        # Получаем все кофейни
        cafes = self.cafe_repository.get_all_cafes()
        
        # Фильтруем кофейни по расстоянию
        nearby_cafes = []
        for cafe in cafes:
            cafe_lat = cafe.coordinates.get("latitude", 0)
            cafe_lon = cafe.coordinates.get("longitude", 0)
            
            distance = self.calculate_distance(user_lat, user_lon, cafe_lat, cafe_lon)
            
            if distance <= radius:
                nearby_cafes.append(cafe)
        
        return nearby_cafes
    
    def check_favorite_cafes_nearby(self, user_id: int, radius: float = 0.2) -> List[Cafe]:
        """
        Проверка наличия избранных кофеен рядом с пользователем.
        
        Args:
            user_id: ID пользователя
            radius: Радиус поиска в километрах (по умолчанию 200 метров)
            
        Returns:
            Список ближайших избранных кофеен
        """
        # Получаем пользователя
        user = self.user_repository.get_user_by_id(user_id)
        
        if not user:
            return []
        
        # Получаем ближайшие кофейни
        nearby_cafes = self.check_nearby_cafes(user_id, radius)
        
        # Фильтруем по избранным
        favorite_cafes = [cafe for cafe in nearby_cafes if cafe.id in user.favorite_cafes]
        
        return favorite_cafes


class NotificationService:
    """
    Сервис для генерации и управления уведомлениями.
    """
    def __init__(self, location_tracker: LocationTracker = None, cafe_repository: CafeRepository = None):
        """
        Инициализация сервиса уведомлений.
        
        Args:
            location_tracker: Трекер местоположения
            cafe_repository: Репозиторий кофеен
        """
        self.location_tracker = location_tracker or LocationTracker()
        self.cafe_repository = cafe_repository or CafeRepository()
        self.notifications = {}  # Словарь для хранения уведомлений пользователей
        self.cafe_presence = {}  # Словарь для отслеживания времени пребывания рядом с кофейнями
    
    def check_and_generate_notifications(self, user_id: int) -> List[Dict[str, Any]]:
        """
        Проверка условий и генерация уведомлений для пользователя.
        
        Args:
            user_id: ID пользователя
            
        Returns:
            Список новых уведомлений
        """
        # Получаем избранные кофейни рядом с пользователем
        favorite_cafes_nearby = self.location_tracker.check_favorite_cafes_nearby(user_id)
        
        # Текущее время
        current_time = int(time.time())
        
        # Инициализируем структуры данных для пользователя, если их еще нет
        if user_id not in self.cafe_presence:
            self.cafe_presence[user_id] = {}
        
        if user_id not in self.notifications:
            self.notifications[user_id] = []
        
        # Обновляем время пребывания рядом с кофейнями
        for cafe in favorite_cafes_nearby:
            if cafe.id not in self.cafe_presence[user_id]:
                # Первое обнаружение рядом с кофейней
                self.cafe_presence[user_id][cafe.id] = {
                    "first_detected": current_time,
                    "last_checked": current_time,
                    "notified": False
                }
            else:
                # Обновляем время последней проверки
                self.cafe_presence[user_id][cafe.id]["last_checked"] = current_time
        
        # Проверяем кофейни, рядом с которыми пользователь находится более 10 минут
        new_notifications = []
        for cafe_id, presence_data in self.cafe_presence[user_id].items():
            # Проверяем, находится ли пользователь все еще рядом с кофейней
            cafe_still_nearby = any(cafe.id == cafe_id for cafe in favorite_cafes_nearby)
            
            if not cafe_still_nearby:
                # Пользователь больше не рядом с кофейней, сбрасываем отслеживание
                presence_data["first_detected"] = current_time
                presence_data["notified"] = False
                continue
            
            # Вычисляем время пребывания рядом с кофейней в минутах
            presence_duration = (current_time - presence_data["first_detected"]) / 60
            
            # Если пользователь находится рядом с кофейней более 10 минут и уведомление еще не отправлено
            if presence_duration >= 10 and not presence_data["notified"]:
                # Получаем информацию о кофейне
                cafe = self.cafe_repository.get_cafe_by_id(cafe_id)
                
                if cafe:
                    # Создаем уведомление
                    notification = {
                        "id": len(self.notifications[user_id]) + 1,
                        "user_id": user_id,
                        "cafe_id": cafe_id,
                        "cafe_name": cafe.name,
                        "message": f"Вы находитесь недалеко от кофейни '{cafe.name}'. Хотите оценить сервис?",
                        "timestamp": current_time,
                        "read": False,
                        "action": "rate_cafe"
                    }
                    
                    # Добавляем уведомление в список
                    self.notifications[user_id].append(notification)
                    new_notifications.append(notification)
                    
                    # Отмечаем, что уведомление отправлено
                    presence_data["notified"] = True
                    
                    # Записываем посещение
                    visit = Visit(
                        user_id=user_id,
                        cafe_id=cafe_id,
                        timestamp=current_time,
                        duration=int(presence_duration)
                    )
                    self.cafe_repository.create_visit(visit)
        
        return new_notifications
    
    def get_user_notifications(self, user_id: int, unread_only: bool = False) -> List[Dict[str, Any]]:
        """
        Получение уведомлений пользователя.
        
        Args:
            user_id: ID пользователя
            unread_only: Флаг для получения только непрочитанных уведомлений
            
        Returns:
            Список уведомлений
        """
        if user_id not in self.notifications:
            return []
        
        if unread_only:
            return [n for n in self.notifications[user_id] if not n.get("read", False)]
        
        return self.notifications[user_id]
    
    def mark_notification_as_read(self, user_id: int, notification_id: int) -> bool:
        """
        Отметка уведомления как прочитанного.
        
        Args:
            user_id: ID пользователя
            notification_id: ID уведомления
            
        Returns:
            True, если уведомление успешно отмечено, иначе False
        """
        if user_id not in self.notifications:
            return False
        
        for notification in self.notifications[user_id]:
            if notification.get("id") == notification_id:
                notification["read"] = True
                return True
        
        return False
    
    def handle_notification_action(self, user_id: int, notification_id: int, action_data: Dict[str, Any]) -> Tuple[bool, str]:
        """
        Обработка действия по уведомлению.
        
        Args:
            user_id: ID пользователя
            notification_id: ID уведомления
            action_data: Данные действия
            
        Returns:
            Кортеж (успех, сообщение)
        """
        if user_id not in self.notifications:
            return False, "Уведомления не найдены"
        
        # Ищем уведомление
        notification = None
        for n in self.notifications[user_id]:
            if n.get("id") == notification_id:
                notification = n
                break
        
        if not notification:
            return False, "Уведомление не найдено"
        
        # Обрабатываем действие в зависимости от типа уведомления
        if notification.get("action") == "rate_cafe":
            # Получаем оценку из данных действия
            rating = action_data.get("rating")
            
            if rating is None:
                return False, "Оценка не указана"
            
            try:
                rating = float(rating)
                if rating < 1 or rating > 5:
                    return False, "Оценка должна быть от 1 до 5"
            except ValueError:
                return False, "Некорректная оценка"
            
            # Получаем ID кофейни из уведомления
            cafe_id = notification.get("cafe_id")
            
            if not cafe_id:
                return False, "ID кофейни не найден в уведомлении"
            
            # Получаем последнее посещение пользователем этой кофейни
            visits = self.cafe_repository.get_visits_by_user(user_id)
            cafe_visits = [v for v in visits if v.cafe_id == cafe_id]
            
            if not cafe_visits:
                return False, "Посещение не найдено"
            
            # Сортируем по времени (от новых к старым)
            cafe_visits.sort(key=lambda v: v.timestamp, reverse=True)
            latest_visit = cafe_visits[0]
            
            # Устанавливаем оценку
            latest_visit.set_rating(rating)
            
            # Сохраняем изменения
            if self.cafe_repository.update_visit(latest_visit):
                # Обновляем рейтинг кофейни
                cafe = self.cafe_repository.get_cafe_by_id(cafe_id)
                if cafe:
                    # Получаем все посещения кофейни с оценками
                    all_visits = self.cafe_repository.get_visits_by_cafe(cafe_id)
                    rated_visits = [v for v in all_visits if v.rating is not None]
                    
                    if rated_visits:
                        # Вычисляем средний рейтинг
                        avg_rating = sum(v.rating for v in rated_visits) / len(rated_visits)
                        
                        # Обновляем рейтинг кофейни
                        cafe.update_rating(avg_rating)
                        self.cafe_repository.update_cafe(cafe)
                
                # Отмечаем уведомление как прочитанное
                notification["read"] = True
                
                return True, "Оценка успешно сохранена"
            
            return False, "Ошибка при сохранении оценки"
        
        return False, "Неизвестное действие"
