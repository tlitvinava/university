"""
Custom Text плагин для сериализации/десериализации.

Этот плагин реализует сериализацию/десериализацию данных в пользовательский текстовый формат.
Формат представляет собой простой текстовый формат с разделителями и маркерами типов данных.

Формат:
- Словари: #DICT# ключ1=значение1; ключ2=значение2; ... #END#
- Списки: #LIST# значение1, значение2, ... #END#
- Строки: #STR# значение #END#
- Числа: #NUM# значение #END#
- Булевы значения: #BOOL# True/False #END#
- None: #NONE# #END#
"""
import os
import re
from typing import Any, Dict, List, Optional, Tuple, Union


class CustomTextSerializer:
    """
    Класс для сериализации/десериализации данных в пользовательский текстовый формат.
    """
    
    def serialize(self, data: Any) -> str:
        """
        Сериализация данных в текстовую строку.
        
        Args:
            data: Данные для сериализации
            
        Returns:
            Текстовая строка
        """
        try:
            return self._serialize_value(data)
        except Exception as e:
            print(f"Ошибка сериализации в текст: {str(e)}")
            return ""
    
    def _serialize_value(self, value: Any) -> str:
        """
        Сериализация значения в зависимости от его типа.
        
        Args:
            value: Значение для сериализации
            
        Returns:
            Сериализованная строка
        """
        if value is None:
            return "#NONE# #END#"
        elif isinstance(value, bool):
            return f"#BOOL# {str(value)} #END#"
        elif isinstance(value, (int, float)):
            return f"#NUM# {value} #END#"
        elif isinstance(value, str):
            # Экранируем специальные символы
            escaped_value = value.replace('#', '\\#').replace(';', '\\;').replace(',', '\\,').replace('=', '\\=')
            return f"#STR# {escaped_value} #END#"
        elif isinstance(value, list):
            items = [self._serialize_value(item) for item in value]
            return f"#LIST# {', '.join(items)} #END#"
        elif isinstance(value, dict):
            items = [f"{self._serialize_value(k)}={self._serialize_value(v)}" for k, v in value.items()]
            return f"#DICT# {'; '.join(items)} #END#"
        else:
            # Для неподдерживаемых типов преобразуем в строку
            return f"#STR# {str(value)} #END#"
    
    def deserialize(self, data_str: str) -> Any:
        """
        Десериализация текстовой строки в данные.
        
        Args:
            data_str: Текстовая строка для десериализации
            
        Returns:
            Десериализованные данные
        """
        try:
            result, _ = self._deserialize_value(data_str, 0)
            return result
        except Exception as e:
            print(f"Ошибка десериализации из текста: {str(e)}")
            return None
    
    def _deserialize_value(self, data_str: str, start_pos: int) -> Tuple[Any, int]:
        """
        Десериализация значения из строки, начиная с указанной позиции.
        
        Args:
            data_str: Строка для десериализации
            start_pos: Начальная позиция
            
        Returns:
            Кортеж (десериализованное значение, новая позиция)
        """
        # Пропускаем пробелы
        pos = start_pos
        while pos < len(data_str) and data_str[pos].isspace():
            pos += 1
        
        if pos >= len(data_str):
            return None, pos
        
        # Определяем тип значения
        if data_str[pos:pos+6] == "#NONE#":
            end_pos = data_str.find("#END#", pos + 6)
            return None, end_pos + 5
        
        elif data_str[pos:pos+6] == "#BOOL#":
            end_pos = data_str.find("#END#", pos + 6)
            value_str = data_str[pos+6:end_pos].strip()
            return value_str == "True", end_pos + 5
        
        elif data_str[pos:pos+5] == "#NUM#":
            end_pos = data_str.find("#END#", pos + 5)
            value_str = data_str[pos+5:end_pos].strip()
            
            # Определяем, целое число или с плавающей точкой
            if '.' in value_str:
                return float(value_str), end_pos + 5
            else:
                return int(value_str), end_pos + 5
        
        elif data_str[pos:pos+5] == "#STR#":
            end_pos = pos + 5
            # Ищем неэкранированный #END#
            while True:
                end_marker = data_str.find("#END#", end_pos)
                if end_marker == -1:
                    raise ValueError("Незакрытый строковый литерал")
                
                # Проверяем, не экранирован ли маркер
                if data_str[end_marker-1] != '\\':
                    break
                
                end_pos = end_marker + 1
            
            value_str = data_str[pos+5:end_marker].strip()
            # Убираем экранирование
            value_str = value_str.replace('\\#', '#').replace('\\;', ';').replace('\\,', ',').replace('\\=', '=')
            return value_str, end_marker + 5
        
        elif data_str[pos:pos+6] == "#LIST#":
            result = []
            pos += 6
            
            # Пропускаем пробелы
            while pos < len(data_str) and data_str[pos].isspace():
                pos += 1
            
            # Пустой список
            if data_str[pos:pos+5] == "#END#":
                return result, pos + 5
            
            # Парсим элементы списка
            while pos < len(data_str):
                # Пропускаем пробелы
                while pos < len(data_str) and data_str[pos].isspace():
                    pos += 1
                
                # Проверяем конец списка
                if data_str[pos:pos+5] == "#END#":
                    return result, pos + 5
                
                # Парсим элемент
                value, pos = self._deserialize_value(data_str, pos)
                result.append(value)
                
                # Пропускаем пробелы
                while pos < len(data_str) and data_str[pos].isspace():
                    pos += 1
                
                # Проверяем разделитель или конец списка
                if data_str[pos:pos+5] == "#END#":
                    return result, pos + 5
                
                if data_str[pos] == ',':
                    pos += 1
                else:
                    raise ValueError(f"Ожидался разделитель ',' или конец списка, получено: {data_str[pos:]}")
            
            raise ValueError("Незакрытый список")
        
        elif data_str[pos:pos+6] == "#DICT#":
            result = {}
            pos += 6
            
            # Пропускаем пробелы
            while pos < len(data_str) and data_str[pos].isspace():
                pos += 1
            
            # Пустой словарь
            if data_str[pos:pos+5] == "#END#":
                return result, pos + 5
            
            # Парсим пары ключ-значение
            while pos < len(data_str):
                # Пропускаем пробелы
                while pos < len(data_str) and data_str[pos].isspace():
                    pos += 1
                
                # Проверяем конец словаря
                if data_str[pos:pos+5] == "#END#":
                    return result, pos + 5
                
                # Парсим ключ
                key, pos = self._deserialize_value(data_str, pos)
                
                # Пропускаем пробелы
                while pos < len(data_str) and data_str[pos].isspace():
                    pos += 1
                
                # Проверяем разделитель ключ-значение
                if data_str[pos] != '=':
                    raise ValueError(f"Ожидался разделитель '=', получено: {data_str[pos:]}")
                
                pos += 1
                
                # Парсим значение
                value, pos = self._deserialize_value(data_str, pos)
                result[key] = value
                
                # Пропускаем пробелы
                while pos < len(data_str) and data_str[pos].isspace():
                    pos += 1
                
                # Проверяем разделитель или конец словаря
                if data_str[pos:pos+5] == "#END#":
                    return result, pos + 5
                
                if data_str[pos] == ';':
                    pos += 1
                else:
                    raise ValueError(f"Ожидался разделитель ';' или конец словаря, получено: {data_str[pos:]}")
            
            raise ValueError("Незакрытый словарь")
        
        else:
            raise ValueError(f"Неизвестный тип данных: {data_str[pos:]}")
    
    def serialize_to_file(self, data: Any, file_path: str) -> bool:
        """
        Сериализация данных в текстовый файл.
        
        Args:
            data: Данные для сериализации
            file_path: Путь к файлу
            
        Returns:
            True, если сериализация успешна, иначе False
        """
        try:
            # Создаем директорию, если она не существует
            os.makedirs(os.path.dirname(os.path.abspath(file_path)), exist_ok=True)
            
            # Сериализуем данные
            serialized_data = self.serialize(data)
            
            # Записываем в файл
            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(serialized_data)
            
            return True
        except Exception as e:
            print(f"Ошибка сериализации в файл: {str(e)}")
            return False
    
    def deserialize_from_file(self, file_path: str) -> Any:
        """
        Десериализация данных из текстового файла.
        
        Args:
            file_path: Путь к файлу
            
        Returns:
            Десериализованные данные
        """
        try:
            if not os.path.exists(file_path):
                print(f"Файл не существует: {file_path}")
                return None
            
            # Читаем файл
            with open(file_path, 'r', encoding='utf-8') as f:
                data_str = f.read()
            
            # Десериализуем данные
            return self.deserialize(data_str)
        except Exception as e:
            print(f"Ошибка десериализации из файла: {str(e)}")
            return None
